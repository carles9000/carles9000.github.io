//	------------------------------------------------------------------------------
//	Project.......: basic_menu
//	Description...: Example use pluggin sidebar menu
//	Date..........: 29/07/2021  
//	Authors.......: Carles Aubia
//	------------------------------------------------------------------------------

	{% LoadHrb( 'lib/mercury/mercury.hrb' ) %}		//	Loading system MVC Mercury
	
//	------------------------------------------------------------------------------

{% MercuryRouter() %}								//	Config system Route
	
function Main()

	InitApp()		
	
retu nil





