#include {% MercuryInclude( 'lib/mercury' ) %}

CLASS Process

	METHOD New( oController )			CONSTRUCTOR

	METHOD Proc1( oController )						
	METHOD Proc2( oController )						
	METHOD Proc3( oController )						
	
	METHOD Info( oController )						
	METHOD About( oController )						
		
ENDCLASS   

//----------------------------------------------------------------------------//

METHOD New( oController ) CLASS Process

	
RETU Self 

//----------------------------------------------------------------------------//

METHOD Proc1( oController ) CLASS Process	
	
	oController:View( 'proc.view', 'menuitem 1' )						 			
	
RETU nil

//----------------------------------------------------------------------------//

METHOD Proc2( oController ) CLASS Process	
	
	oController:View( 'proc.view', 'menuitem 2' )						 			
	
RETU nil

//----------------------------------------------------------------------------//

METHOD Proc3( oController ) CLASS Process	
	
	oController:View( 'proc.view', 'menuitem 3' )						 			
	
RETU nil


//----------------------------------------------------------------------------//

METHOD Info( oController ) CLASS Process	
	
	oController:View( 'proc.view', 'Info' )						 			
	
RETU nil


//----------------------------------------------------------------------------//

METHOD About( oController ) CLASS Process	
	
	oController:View( 'proc.view', 'About' )						 			
	
RETU nil

//----------------------------------------------------------------------------//
