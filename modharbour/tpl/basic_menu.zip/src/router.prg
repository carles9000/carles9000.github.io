#include {% MercuryInclude() %}

static __hToken 	:= NIL

function InitApp()

	local oApp 	
		
	//	Define App

		DEFINE APP oApp 
		
		//	Config Routes									
			
			DEFINE ROUTE 'root'		URL '/'  	VIEW 		'hello.view'  		METHOD 'GET' 	OF oApp		
			DEFINE ROUTE 'main'		URL 'main'	CONTROLLER  'main@menu.prg' 	METHOD 'GET' 	OF oApp

			DEFINE ROUTE 'proc1' 	URL 'proc1'	CONTROLLER  'proc1@process.prg' METHOD 'GET' 	OF oApp			
			DEFINE ROUTE 'proc2' 	URL 'proc2'	CONTROLLER  'proc2@process.prg' METHOD 'GET' 	OF oApp			
			DEFINE ROUTE 'proc3' 	URL 'proc3'	CONTROLLER  'proc3@process.prg' METHOD 'GET' 	OF oApp			
			
			DEFINE ROUTE 'info' 	URL 'info'	CONTROLLER  'info@process.prg' 	METHOD 'GET' 	OF oApp			
			DEFINE ROUTE 'about' 	URL 'about'	CONTROLLER  'about@process.prg' METHOD 'GET' 	OF oApp			

		INIT APP oApp	

return nil

function AppUrlImg(); 				retu App_Url() + '/images/'
function AppUrlLib(); 				retu App_Url() + '/lib/'

function AppIniMenu(); 				retu 'basic_menu'