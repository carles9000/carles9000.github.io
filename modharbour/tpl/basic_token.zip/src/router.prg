#include {% MercuryInclude() %}

function InitApp()

	local oApp 	
		
	//	Define App

		DEFINE APP oApp ;			
			CREDENTIALS 'mERCuRy@2021!' COOKIE 'mercury'		
		
			//	Test JWT	
			
			DEFINE ROUTE 'jwt'				URL '/' 			CONTROLLER 'create@test_jwt.prg'	METHOD 'GET'	OF oApp
			DEFINE ROUTE 'jwt.valid'		URL 'jwt/valid' 	CONTROLLER 'valid@test_jwt.prg'	METHOD 'POST'	OF oApp	
			
			
		INIT APP oApp	

return nil

function AppUrlImg(); 				retu App_Url() + '/images/'
