#include {% MercuryInclude( 'lib/mercury' ) %}

#define HB_CURLOPT_URL                        2
#define HB_CURLOPT_DL_BUFF_SETUP              1008
#define HB_CURLOPT_SSL_VERIFYPEER             64
#define HB_CURLOPT_SSL_VERIFYHOST             81
#define HB_CURLOPT_NOPROGRESS                 43  /* shut off the progress meter */
#define HB_CURLOPT_VERBOSE                    41  /* talk a lot */


CLASS MyController

	METHOD New( oController )			CONSTRUCTOR

	METHOD Example1( oController )			
	METHOD Example2( oController )			
		
		
ENDCLASS   

//----------------------------------------------------------------------------//

METHOD New( oController ) CLASS MyController
	

RETU Self 

//----------------------------------------------------------------------------//

METHOD Example1( oController ) CLASS MyController	

	local hCurl, cBuffer := ""
	local cUrl 	:= "https://picsum.photos/v2/list?page=9&limit=5"

	if ! empty( hCurl := curl_easy_init() )
	

		curl_easy_setopt( hCurl, HB_CURLOPT_URL, cUrl )
		curl_easy_setopt( hCurl, HB_CURLOPT_SSL_VERIFYPEER, .f. )
		curl_easy_setopt( hCurl, HB_CURLOPT_SSL_VERIFYHOST, .t. )
		curl_easy_setopt( hCurl, HB_CURLOPT_NOPROGRESS, .f. )
		curl_easy_setopt( hCurl, HB_CURLOPT_VERBOSE, .t. )
		curl_easy_setopt( hCurl, HB_CURLOPT_DL_BUFF_SETUP )

		if curl_easy_perform(hCurl) == 0
			cBuffer := curl_easy_dl_buff_get( hCurl )

			if !empty(cBuffer)		
				oController:View( 'example1.view' , hb_jsondecode( cBuffer ) )
			endif
		endif
		
		curl_easy_cleanup( hCurl )
		
	endif	

RETU nil


//----------------------------------------------------------------------------//

METHOD Example2( oController ) CLASS MyController	

	local cServer 	:= AP_GetEnv( 'SERVER_NAME' )
	local cIp 		:= AP_GetEnv( 'SERVER_ADDR' )

	oController:View( 'example2.view' , cServer, cIp )

RETU nil


//----------------------------------------------------------------------------//