#include {% MercuryInclude() %}

function InitApp()

	local oApp 	
		
	//	Define App

		DEFINE APP oApp 		
		
			//	Cfg. routes Main
			
			DEFINE ROUTE 'root'    	URL '/'      	VIEW 		 'hello.view'  				METHOD 'GET' 	OF oApp		
			
			DEFINE ROUTE 'example1'	URL 'example1' 	CONTROLLER  'example1@mycontroller.prg'	METHOD 'GET' 	OF oApp
			DEFINE ROUTE 'example2'	URL 'example2' 	CONTROLLER  'example2@mycontroller.prg'	METHOD 'GET' 	OF oApp

		INIT APP oApp	

return nil


function AppUrlImg(); 				retu App_Url() + '/images/'
function AppUrlLib(); 				retu App_Url() + '/lib/'
function AppUrlTmp(); 				retu App_Url() + '/tmp/'


