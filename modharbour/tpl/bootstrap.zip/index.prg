//	------------------------------------------------------------------------------
//	Project.......: bootstrap
//	Descripcion...: Esquema basico de como cargar libreria bootstrap y uso de Curl
//  Description...: Basic scheme of bootstrap use and Curl example
//	Date..........: 13/07/21
//	Authors.......: Carles Aubia (Charly)
//	------------------------------------------------------------------------------

	{% LoadHrb( 'lib/mercury/mercury.hrb' ) %}		//	Loading system MVC Mercury

//	------------------------------------------------------------------------------

{% MercuryRouter() %}
	
	
function main()

	InitApp()
	
return nil 	

