//	------------------------------------------------------------------------------
//	Project.......: basic_app
//	Descripcion...: Esquema básico de una usando TWeb //					  
//	Description...: Basic scheme with TWeb
//	Date..........: 22/05/2021
//	Authors.......: Carles Aubia (Charly)
//	------------------------------------------------------------------------------

	{% LoadHrb( 'lib/mercury/mercury.hrb' ) %}		//	Loading system MVC Mercury
	{% LoadHrb( 'lib/tweb/tweb.hrb' ) %}			//	Loading TWeb Library

//	------------------------------------------------------------------------------

{% MercuryRouter() %}
	
	
function main()

	InitApp()
	
return nil 	

