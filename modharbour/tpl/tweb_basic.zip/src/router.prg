#include {% MercuryInclude() %}

//http://localhost/pre/tpl/tweb_basic/app/lib/tweb/lightbox/css/lightbox.css

function InitApp()

	local oApp 	
		
	//	Define App

		DEFINE APP oApp 
		
		//	Initial screen
		
			DEFINE ROUTE 'root'			URL '/' 				VIEW 'default.view'					METHOD 'GET'	OF oApp				
			DEFINE ROUTE 'app.main'		URL 'app/main'			CONTROLLER 'main@myapp.prg'		METHOD 'GET'	OF oApp

			
		//	Modules...
		
			DEFINE ROUTE 'viewsearchrecno'	URL 'app/viewsearchrecno'	CONTROLLER 'viewsearchrecno@myapp.prg'		METHOD 'GET'	OF oApp
			DEFINE ROUTE 'searchrecno'		URL 'app/searchrecno'		CONTROLLER 'searchrecno@myapp.prg'			METHOD 'GET'	OF oApp

			DEFINE ROUTE 'viewliststate'	URL 'app/viewliststate'		CONTROLLER 'viewliststate@myapp.prg'		METHOD 'GET'	OF oApp
			DEFINE ROUTE 'searchstate'		URL 'app/searchstate'		CONTROLLER 'searchstate@myapp.prg'			METHOD 'GET'	OF oApp
			
						
		INIT APP oApp	

return nil

//	Estas funciones son de soporte para nuestro proyecto
//	These functions are support for our project

//	Path absoluto / absolute path

function AppPathData(); 				retu AP_GetEnv( "DOCUMENT_ROOT" ) + App_Url() + '/data/'
function AppPathLib(); 				retu AP_GetEnv( "DOCUMENT_ROOT" ) + App_Url() + '/lib/'


//	Path relativo / relative path

function AppUrlImg(); 				retu App_Url() + '/images/'
function AppUrlLib(); 				retu App_Url() + '/lib/'


function MyConfig() 

	SET DELETED ON
	SET DATE TO ITALIAN	
	SET CENTURY on	
	
retu nil