//	------------------------------------------------------------------------------
//	Project.......: Basic_controller_to_view
//	Description...: How to send different parameteres to the view
//	Date..........: 05/06/2021
//	Authors.......: Charly aubia
//	------------------------------------------------------------------------------

	{% LoadHrb( 'lib/mercury/mercury.hrb' ) %}		//	Loading system MVC Mercury

//	------------------------------------------------------------------------------

{% MercuryRouter() %}
	
	
function main()

	InitApp()
	
return nil 	

