#include {% MercuryInclude( 'lib/mercury' ) %}

CLASS MyController

	METHOD New( oController )			CONSTRUCTOR
			
	METHOD SendHash( oController )			
	METHOD Parameters( oController )			
	METHOD BlocksView( oController )			
	
		
ENDCLASS   

//----------------------------------------------------------------------------//

METHOD New( oController ) CLASS MyController
	

RETU Self 

//----------------------------------------------------------------------------//

METHOD SendHash( oController ) CLASS MyController	

	local hParam := {=>}

	hParam[ 'date' ] := date()
	hParam[ 'time' ] := time()
	hParam[ 'name' ] := 'Paul Britman'
	
	oController:View( 'hash.view', hParam )

RETU nil

//----------------------------------------------------------------------------//

METHOD Parameters( oController ) CLASS MyController	

	local nTicket 	:= hb_milliseconds()
	local cUser 	:= 'Marc Gooldwerg'

	oController:View( 'parameters.view', nTicket, cUser )

RETU nil

//----------------------------------------------------------------------------//

METHOD BlocksView( oController ) CLASS MyController	

	local nTicket 	:= hb_milliseconds()
	local cUser 	:= 'Marc Gooldwerg'

	oController:View( 'blocks_view.view', nTicket, cUser )

RETU nil
