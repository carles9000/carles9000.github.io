#include {% MercuryInclude() %}

function InitApp()

	local oApp 	
		
	//	Define App

		DEFINE APP oApp 	
		
			//	Cfg. routes Main
			
			DEFINE ROUTE 'root'    	URL '/'      			VIEW 		 'hello.view'  					METHOD 'GET' 	OF oApp		

			DEFINE ROUTE 'parameters'	URL 'parameters'		CONTROLLER  'parameters@mycontroller.prg'	METHOD 'GET' 	OF oApp
			DEFINE ROUTE 'blocksview'	URL 'blocksview'		CONTROLLER  'blocksview@mycontroller.prg'	METHOD 'GET' 	OF oApp
			DEFINE ROUTE 'route'		URL 'route'				VIEW  		 'route.view'					METHOD 'GET' 	OF oApp
			DEFINE ROUTE 'sendhash'	URL 'sendhash'			CONTROLLER  'sendhash@mycontroller.prg'	METHOD 'GET' 	OF oApp
			
						
		INIT APP oApp	

return nil

function AppUrlImg(); 				retu App_Url() + '/images/'
function AppUrlLib(); 				retu App_Url() + '/lib/'




