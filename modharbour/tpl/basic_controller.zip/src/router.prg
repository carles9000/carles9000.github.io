#include {% MercuryInclude() %}

function InitApp()

	local oApp 	
		
	//	Define App

		DEFINE APP oApp 	
		
			//	Cfg. routes Main
				
			DEFINE ROUTE 'root'    		URL '/'      			VIEW 		 'hello.view'  						METHOD 'GET' 	OF oApp		
			DEFINE ROUTE 'form.post'		URL 'form/post' 		CONTROLLER  'formpost@mycontroller.prg'		METHOD 'GET' 	OF oApp
			DEFINE ROUTE 'form.readpost'	URL 'form/readpost' 	CONTROLLER  'formreadpost@mycontroller.prg'	METHOD 'POST' 	OF oApp
			DEFINE ROUTE 'form.get'		URL 'form/get' 			CONTROLLER  'formget@mycontroller.prg'			METHOD 'GET' 	OF oApp
			DEFINE ROUTE 'form.readget'	URL 'form/readget' 		CONTROLLER  'formreadget@mycontroller.prg'		METHOD 'GET' 	OF oApp
						
			DEFINE ROUTE 'ajax.view'		URL 'ajax/view' 		CONTROLLER  'view@ajaxcontroller.prg'			METHOD 'GET' 	OF oApp
			DEFINE ROUTE 'ajax.readpost'	URL 'ajax/readpost'		CONTROLLER  'readpost@ajaxcontroller.prg'		METHOD 'POST' 	OF oApp
			DEFINE ROUTE 'ajax.readget'	URL 'ajax/readget'		CONTROLLER  'readget@ajaxcontroller.prg'		METHOD 'GET' 	OF oApp
			
			DEFINE ROUTE 'info'			URL 'info'				CONTROLLER  'info@mycontroller.prg'			METHOD 'GET' 	OF oApp
			
		INIT APP oApp	

return nil


function AppUrlImg(); 				retu App_Url() + '/images/'
function AppUrlLib(); 				retu App_Url() + '/lib/'

