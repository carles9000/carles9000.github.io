#include {% MercuryInclude( 'lib/mercury' ) %}

CLASS AjaxController

	METHOD New( oController )			CONSTRUCTOR

	METHOD View( oController )					
	
	METHOD ReadPost( oController )			
	METHOD ReadGet( oController )						
		
ENDCLASS   

//----------------------------------------------------------------------------//

METHOD New( oController ) CLASS AjaxController
	

RETU Self 


//----------------------------------------------------------------------------//

METHOD View( oController ) CLASS AjaxController	

	oController:View( 'ajax.view' )

RETU nil

//----------------------------------------------------------------------------//

METHOD ReadPost( oController ) CLASS AjaxController	

	//	Recupero los parametros con alguno de los metodos vistos en el ejemplo Form
	//	I recover the parameters with some of the methods seen in the Form example

		local cMethod 	:= oController:oRequest:Method() 
		local hParam 	:= oController:oRequest:PostAll()

	
	//	Como es una peticion Ajax, devolvere los mismos parámetros, junto al metodo 
	//	As it is an Ajax request, I will return the same parameters, together with the method
	
		oController:oResponse:SendJson( { 'parameters' => hParam, 'method' => cMethod } )

RETU nil

//----------------------------------------------------------------------------//

METHOD ReadGet( oController ) CLASS AjaxController	

	//	Recupero los parametros con alguno de los metodos vistos en el ejemplo Form
	//	I recover the parameters with some of the methods seen in the Form example

		local cMethod 	:= oController:oRequest:Method() 
		local hParam 	:= oController:oRequest:GetAll()

	
	//	Como es una peticion Ajax, devolvere los mismos parámetros, junto al metodo 
	//	As it is an Ajax request, I will return the same parameters, together with the method
	
		oController:oResponse:SendJson( { 'parameters' => hParam, 'method' => cMethod } )

RETU nil

//----------------------------------------------------------------------------//