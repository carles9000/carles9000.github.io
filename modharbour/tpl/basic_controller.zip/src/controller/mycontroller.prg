#include {% MercuryInclude( 'lib/mercury' ) %}

CLASS MyController

	METHOD New( oController )			CONSTRUCTOR

	METHOD formpost( oController )			
	METHOD formget( oController )			
	
	METHOD formreadpost( oController )			
	METHOD formreadget( oController )	
	
	METHOD Info( oController )				
		
ENDCLASS   

//----------------------------------------------------------------------------//

METHOD New( oController ) CLASS MyController
	

RETU Self 


//----------------------------------------------------------------------------//

METHOD FormPost( oController ) CLASS MyController	

	oController:View( 'formpost.view' )

RETU nil

//----------------------------------------------------------------------------//

METHOD FormGet( oController ) CLASS MyController	

	oController:View( 'formget.view' )

RETU nil


//----------------------------------------------------------------------------//

METHOD FormReadPost( oController ) CLASS MyController	

	? '<b>Method used. oController:oRequest:Method() =></b>', oController:oRequest:Method()
	
	? '<br>'

	? '<b>Retrieve all parameters. Standar function Ap_PostPairs()</b>', Ap_PostPairs()
	
	? '<br>'
	
	? '<b>Retrieve all parameters. Object oRequest:PostAll()</b>', oController:oRequest:PostAll()
	
	? '<br>'
	
	? '<b>Retrieve specific parameter. Object oRequest:Post( "name" )</b>', oController:oRequest:Post( "name" )
	
	
	
	//	El controlador envia siempre una respuesta a una view, a una peticion ajax,... 
	//	Para test mostramos aqui el resultado
	//	------------------------------------------------------------------------------
	//	The controller always sends a response to a view, to an ajax request, ...
	//	For test we show here the result

RETU nil


//----------------------------------------------------------------------------//

METHOD FormReadGet( oController ) CLASS MyController	

	? '<b>Method used. oController:oRequest:Method() =></b>', oController:oRequest:Method()
	
	? '<br>'

	? '<b>Retrieve all parameters. Standard function Ap_GetPairs()</b>', Ap_GetPairs()
	
	? '<br>'
	
	? '<b>Retrieve all parameters. Object oRequest:GetAll()</b>', oController:oRequest:GetAll()
	
	? '<br>'
	
	? '<b>Retrieve specific parameter. Object oRequest:Get( "name" )</b>', oController:oRequest:Get( "name" )
	
	
	
	//	El controlador envia siempre una respuesta a una view, a una peticion ajax,... 
	//	Para test mostramos aqui el resultado
	//	------------------------------------------------------------------------------
	//	The controller always sends a response to a view, to an ajax request, ...
	//	For test we show here the result

RETU nil

//----------------------------------------------------------------------------//

METHOD Info( oController ) CLASS MyController	

	//	Estos metodos son para ayudar a comprobar diferentes parámetros del sistema 
	//	These methods are to help check different parameters of the system

	oController:ListController()	
	oController:ListRoute()	

retu nil
//----------------------------------------------------------------------------//