#include {% MercuryInclude() %}

CLASS MyApp

	METHOD New( oController )			CONSTRUCTOR

	METHOD SearchId()						//	Search Recno
	METHOD SearchState()					//	Search rows with state
	
	METHOD MyData( oController )			//	Recover data token
		
ENDCLASS   

//----------------------------------------------------------------------------//

METHOD New( oController ) CLASS MyApp

	//	Punto importante de la aplicacion. Seguridad del sistema
	//	Podemos de una manera muy sencilla controlar el acceso a este controlador
	//	En este caso le indicamos que en el caso de NO estar autenticado, se dirija 
	//	a la pantalla definida el el router con la clave 'sys.login'
	//	
	//	En un controlador podemos tener varios metodos y es posible que alguna queramos
	//	que sea publico. En este caso podemos crear excepciones con el command 
	//	EXCEPTION <nombre de metodo/s>. Aqui lo hacemos con el método 'test2'
	//	--------------------------------------------------------------------------------
	//	Important point of the application. System security
	//	We can in a very simple way control access to this controller
	//	In this case we indicate that in the case of NOT being authenticated, go
	//	to the screen defined on the router with the key 'sys.login'
	//
	//	In a controller we can have several methods and it is possible that some of us want
	//	make it public. In this case we can create exceptions with the command
	//	EXCEPTION <method name / s>. Here we do it with the 'test2' method

		AUTENTICATE CONTROLLER oController VIA 'token' ;
			ERROR JSON { 'success' => .f. , 'error' => 'Error autentication' }

	
	//	Si se llega a este punto es que se ha autenticado correctamente... :-) 
	//	If you get to this point, you have successfully authenticated ... :-)		
	
RETU Self 

//----------------------------------------------------------------------------//
//	Este método se podra ejecutar sin necesidad de autenticarse. Ver método New()
//	En cualquier momento podremos en la url especificar ../basic_tpl/app/test2
//----------------------------------------------------------------------------//
//	This method can be executed without the need to authenticate. See New() method
//	At any time we can specify in the url ../basic_tpl/app/test2

//----------------------------------------------------------------------------//

METHOD SearchId( oController ) CLASS MyApp

	local hParam		:= oController:oRequest:GetAll()
	local hData 		:= {=>}
	local oValidator, oTest
	
	//	Validamos parámetros / We validate parameters ------------------------------
	
		DEFINE VALIDATOR oValidator WITH  hParam 

			PARAMETER 'id' 	NAME 'Recno' 	ROLES 'required|numeric|maxlen:8' FORMATTER 'tonumber' OF oValidator				
			
		RUN VALIDATOR oValidator	

		if oValidator:lError					
			oController:oResponse:SendJson( { 'success' => .f., 'error' => oValidator:ErrorString() } )					
			retu nil
		endif	
		
	//	Abrimos modelos de datos / Open model data
	
		oTest		:= TestModel():New()

	//	Recuperamos datos del modelo	/ Recover data from model 
		
		hData := oTest:Get( hParam[ 'id' ] )
		
	//	Enviamos datos a la vista / Send data to view

		oController:oResponse:SendJson({ 'success' => .t. , 'data' => hData } )
	
RETU NIL

//----------------------------------------------------------------------------//

METHOD SearchState( oController ) CLASS MyApp

	local hParam		:= oController:oRequest:GetAll()
	local aRows 		:= {}
	local nRows 		:= 0
	local nTotal 		:= 0
	local oValidator, oTest
	
	//	Validamos parámetros / We validate parameters ------------------------------
	
		DEFINE VALIDATOR oValidator WITH  hParam 

			PARAMETER 'state' 	NAME 'State' 	ROLES 'required|maxlen:2' FORMATTER 'upper' OF oValidator				
			
		RUN VALIDATOR oValidator	

		if oValidator:lError					
			oController:oResponse:SendJson( { 'success' => .f., 'error' => oValidator:ErrorString() } )				
			retu nil
		endif	
		
	//	Abrimos modelos de datos / Open model data
	
		oTest	:= TestModel():New()

	//	Recuperamos datos del modelo	/ Recover data from model 
		
		aRows 	:= oTest:RowsByState( hParam[ 'state' ] )
		nRows 	:= len(aRows) 
		
	//	Calculamos media de edad / We calculate age average
	
		AEval( aRows, {|hRow| nTotal += hRow[ 'AGE'] } )		
		
		nAverage := nTotal / nRows 

		
	//	Enviamos datos a la vista / Send data to view
		
		oController:oResponse:SendJson({ 'success' => .t. , 'state' => hParam[ 'state' ], 'len' => nRows, 'average' => nAverage, 'rows' => aRows } )
	
RETU NIL

METHOD MyData( oController ) CLASS MyApp

	local hData 
	
	GET TOKEN hData OF oController
	
	oController:oResponse:SendJson( { 'data' => hData } )
	
RETU NIL	
	
	

//----------------------------------------------------------------------------//
//	Quizas a tener en cuenta, que nosotros cargamos la clase TestModel en la 
//	linea inferior con la funcion LoadFile(). Recordad que nosotros no enlazamos
//	todas las funciones como hacemos cuando creamos un exe. Por lo tanto deberemos
//	siempre especificar los diferentes modulos que usaremos.
//	Observa tambien que ponemos la funcion entre los tags { %  ...  % }. Estos tags
//	Indican al mod pre-ejecutar el codigo que tiene dentro antes de compilar el módulo
//----------------------------------------------------------------------------//
//	Maybe to keep in mind, that we load the TestModel class in the
//	bottom line with the LoadFile() function. Remember that we do not link
//	all the functions as we do when we create an exe. Therefore we must
//	always specify the different modules that we will use.
//	Also notice that we put the function between the { % ...  % } tags. These tags
//	They tell the mod to pre-execute the code it has inside before compiling the module

{% LoadFile( "/src/model/testmodel.prg" ) %}

