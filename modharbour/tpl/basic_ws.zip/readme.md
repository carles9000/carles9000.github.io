Hi !

Please read the doc .\doc\ws.pdf to understand the use of the webservices...

Enjoy it ! 