Hi !

.\doc\ws.pdf 

Enjoy it ! 