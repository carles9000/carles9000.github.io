//	------------------------------------------------------------------------------
//	Project.......: basic_app
//	Descripcion...: Esquema básico de una aplicacion MVC con autenticación y uso 
//					  de modelo de datos
//	Description...: Basic scheme of an MVC application with authentication and 
//	                 model data use 
//	Date..........: 22/05/2021
//	Authors.......: Carles Aubia (Charly)
//	------------------------------------------------------------------------------

	{% LoadHrb( 'lib/mercury/mercury.hrb' ) %}		//	Loading system MVC Mercury

//	------------------------------------------------------------------------------

{% MercuryRouter() %}
	
	
function main()

	InitApp()
	
return nil 	

