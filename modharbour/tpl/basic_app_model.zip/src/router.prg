#include {% MercuryInclude() %}

function InitApp()

	local oApp 	
		
	//	Define App

		DEFINE APP oApp ;
			ON INIT MyConfig() ;
			CREDENTIALS 'mERCuRy@2021!' COOKIE 'myapp'	

		//	Initial screen
		
			DEFINE ROUTE 'root'			URL '/' 				VIEW 'default.view'					METHOD 'GET'	OF oApp				
			DEFINE ROUTE 'app.main'		URL 'app/main'			CONTROLLER 'main@myapp.prg'		METHOD 'GET'	OF oApp

			
		//	Modules...
		
			DEFINE ROUTE 'viewsearchrecno'	URL 'app/viewsearchrecno'	CONTROLLER 'viewsearchrecno@myapp.prg'		METHOD 'GET'	OF oApp
			DEFINE ROUTE 'searchrecno'		URL 'app/searchrecno'		CONTROLLER 'searchrecno@myapp.prg'			METHOD 'GET'	OF oApp

			DEFINE ROUTE 'viewliststate'	URL 'app/viewliststate'		CONTROLLER 'viewliststate@myapp.prg'		METHOD 'GET'	OF oApp
			DEFINE ROUTE 'searchstate'		URL 'app/searchstate'		CONTROLLER 'searchstate@myapp.prg'			METHOD 'GET'	OF oApp
			
		//	Autentication (Login)
		
			DEFINE ROUTE 'sys.login'		URL 'sys/login'			CONTROLLER 'login@access.prg'		METHOD 'GET'	OF oApp
			DEFINE ROUTE 'sys.autentica'	URL 'sys/autentica'		CONTROLLER 'autentica@access.prg'	METHOD 'POST'	OF oApp
			DEFINE ROUTE 'sys.logout'		URL 'sys/logout'		CONTROLLER 'logout@access.prg'		METHOD 'GET'	OF oApp

				
		INIT APP oApp	

return nil

//	Estas funciones son de soporte para nuestro proyecto
//	These functions are support for our project

//	Path absoluto / absolute path

function AppPathData(); 				retu AP_GetEnv( "DOCUMENT_ROOT" ) + Ap_GetEnv( 'PATH_DATA') 


//	Path relativo / relative path

function AppUrlImg(); 				retu App_Url() + '/images/'
function AppUrlLib(); 				retu App_Url() + '/lib/'


function MyConfig() 

	SET DELETED ON
	SET DATE TO ITALIAN	
	SET CENTURY on	
	
retu nil