#include {% MercuryInclude() %}

CLASS MyApp

	METHOD New( oController )			CONSTRUCTOR

	METHOD Default( oController )				
	METHOD Main( oController )	

	METHOD ViewSearchRecno()				//	View
	METHOD ViewListState()				//	View
	
	METHOD SearchRecno()					//	Search Recno
	METHOD SearchState()					//	Search rows with state
		
ENDCLASS   

//----------------------------------------------------------------------------//

METHOD New( oController ) CLASS MyApp

	//	Punto importante de la aplicacion. Seguridad del sistema
	//	Podemos de una manera muy sencilla controlar el acceso a este controlador
	//	En este caso le indicamos que en el caso de NO estar autenticado, se dirija 
	//	a la pantalla definida el el router con la clave 'sys.login'
	//	
	//	En un controlador podemos tener varios metodos y es posible que alguna queramos
	//	que sea publico. En este caso podemos crear excepciones con el command 
	//	EXCEPTION <nombre de metodo/s>. Aqui lo hacemos con el método 'test2'
	//	--------------------------------------------------------------------------------
	//	Important point of the application. System security
	//	We can in a very simple way control access to this controller
	//	In this case we indicate that in the case of NOT being authenticated, go
	//	to the screen defined on the router with the key 'sys.login'
	//
	//	In a controller we can have several methods and it is possible that some of us want
	//	make it public. In this case we can create exceptions with the command
	//	EXCEPTION <method name / s>. Here we do it with the 'test2' method

		AUTENTICATE CONTROLLER oController ERROR ROUTE 'sys.login' 			

	
	//	Si se llega a este punto es que se ha autenticado correctamente... :-) 
	//	If you get to this point, you have successfully authenticated ... :-)		
	
RETU Self 

//----------------------------------------------------------------------------//

METHOD Default( oController ) CLASS MyApp	

	oController:View( 'default.view' )

RETU nil

//----------------------------------------------------------------------------//

METHOD Main( oController ) CLASS MyApp	

	oController:View( 'main.view' )

RETU nil

//----------------------------------------------------------------------------//

METHOD ViewSearchRecno( o ) CLASS MyApp

	o:View( 'app/viewsearchrecno.view' )
	
RETU NIL

//----------------------------------------------------------------------------//

METHOD ViewListState( o ) CLASS MyApp

	o:View( 'app/viewliststate.view' )
	
RETU NIL

//----------------------------------------------------------------------------//
//	Este método se podra ejecutar sin necesidad de autenticarse. Ver método New()
//	En cualquier momento podremos en la url especificar ../basic_tpl/app/test2
//----------------------------------------------------------------------------//
//	This method can be executed without the need to authenticate. See New() method
//	At any time we can specify in the url ../basic_tpl/app/test2

//----------------------------------------------------------------------------//

METHOD SearchRecno( oController ) CLASS MyApp

	local hParam		:= oController:oRequest:GetAll()
	local hData 		:= {=>}
	local oValidator, oTest
	
	//	Validamos parámetros / We validate parameters ------------------------------
	
		DEFINE VALIDATOR oValidator WITH  hParam 

			PARAMETER 'recno' 	NAME 'Recno' 	ROLES 'required|numeric|maxlen:8' FORMATTER 'tonumber' OF oValidator				
			
		RUN VALIDATOR oValidator	

		if oValidator:lError					
			oController:View( 'app/test1.view' ,  oValidator:ErrorString() )					
			retu nil
		endif	
		
	//	Abrimos modelos de datos / Open model data
	
		oTest		:= TestModel():New()

	//	Recuperamos datos del modelo	/ Recover data from model 
		
		hData := oTest:Get( hParam[ 'recno' ] )
		
	//	Enviamos datos a la vista / Send data to view

		oController:View( 'app/showrecno.view', hData )
	
RETU NIL

//----------------------------------------------------------------------------//

METHOD SearchState( oController ) CLASS MyApp

	local hParam		:= oController:oRequest:GetAll()
	local aRows 		:= {}
	local oValidator, oTest
	
	//	Validamos parámetros / We validate parameters ------------------------------
	
		DEFINE VALIDATOR oValidator WITH  hParam 

			PARAMETER 'state' 	NAME 'State' 	ROLES 'required|maxlen:2' OF oValidator				
			
		RUN VALIDATOR oValidator	

		if oValidator:lError					
			oController:View( 'app/viewliststate.view' ,  oValidator:ErrorString() )					
			retu nil
		endif	
		
	//	Abrimos modelos de datos / Open model data
	
		oTest	:= TestModel():New()

	//	Recuperamos datos del modelo	/ Recover data from model 
		
		aRows 	:= oTest:RowsByState( hParam[ 'state' ] )

		
	//	Enviamos datos a la vista / Send data to view

		oController:View( 'app/showrowsbystate.view',  hParam[ 'state' ], aRows )
	
RETU NIL

//----------------------------------------------------------------------------//
//	Quizas a tener en cuenta, que nosotros cargamos la clase TestModel en la 
//	linea inferior con la funcion LoadFile(). Recordad que nosotros no enlazamos
//	todas las funciones como hacemos cuando creamos un exe. Por lo tanto deberemos
//	siempre especificar los diferentes modulos que usaremos.
//	Observa tambien que ponemos la funcion entre los tags { %  ...  % }. Estos tags
//	Indican al mod pre-ejecutar el codigo que tiene dentro antes de compilar el módulo
//----------------------------------------------------------------------------//
//	Maybe to keep in mind, that we load the TestModel class in the
//	bottom line with the LoadFile() function. Remember that we do not link
//	all the functions as we do when we create an exe. Therefore we must
//	always specify the different modules that we will use.
//	Also notice that we put the function between the { % ...  % } tags. These tags
//	They tell the mod to pre-execute the code it has inside before compiling the module

{% LoadFile( "/src/model/testmodel.prg" ) %}

