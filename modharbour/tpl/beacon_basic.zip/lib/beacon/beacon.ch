//----------------------------------------------------------------------------//
//
//----------------------------------------------------------------------------//

#define __BEACON__

#xcommand ? <cText> => AP_RPuts( <cText> )
#xcommand ?? [<explist,...>] => AP_RPuts( [<explist>] )
#xcommand TEXT <into:TO,INTO> <v> => #pragma __cstream|<v>:=%s
#xcommand TEXT <into:TO,INTO> <v> ADDITIVE => #pragma __cstream|<v>+=%s
#xcommand TEXT TO VAR <var> => #pragma __stream|<var>:=%s
#xcommand ENDTEXT => #pragma __endtext
#xcommand HTML => #pragma __text| cHtml+=%s
#xcommand HTML <into:TO,INTO> <v> => #pragma __text| <v>+=%s
#xcommand STYLE <into:TO,INTO> <v> FROM <oDoc> => <oDoc>:SetStyle(  .T., .F., );;
          #pragma __text| <v>+=%s
#xcommand ENDSTYLE <v> FROM <oDoc> => #pragma __endtext;;
                        <oDoc>:SetStyle( .F., .F., <v> );;
                        <oDoc>:EndStyle()
#xcommand DEFAULT <uVar1> := <uVal1> [, <uVarN> := <uValN> ] => ;
            if( <uVar1> == nil, <uVar1> := <uVal1>, ) ;;
            [ if( <uVarN> == nil, <uVarN> := <uValN>, ); ]
#xcommand TRY => BEGIN SEQUENCE WITH {| oErr | Break( oErr ) }
#xcommand CATCH [<!oErr!>] => RECOVER [USING <oErr>] <-oErr->
#xcommand FINALLY => ALWAYS
#xcommand TEMPLATE [ USING <x> ] [ PARAMS [<v1>] [,<vn>] ] => ;
          #pragma __cstream | AP_RPuts( InlinePrg( %s, [@<x>] [,<(v1)>][+","+<(vn)>] [, @<v1>][, @<vn>] ) )
#xcommand ENDTEMPLATE => #pragma __endtext
#xcommand BLOCKS [ PARAMS [<v1>] [,<vn>] ] => ;
          #pragma __cstream | AP_RPuts( ReplaceBlocks( %s, "{{", "}}" [,<(v1)>][+","+<(vn)>] [, @<v1>][, @<vn>] ) )
#xcommand LOGMOD <v> => ModLog( <v>, .T. )
#xtranslate Throw( <oErr> ) => ( Eval( ErrorBlock(), <oErr> ), Break( <oErr> ) )
#xcommand REPEAT        => while .t.
#xcommand DO            => while .t.
#xcommand UNTIL <uExpr> => if <uExpr>; exit; end; end

// ModLog( cStr, lDebug, lLineFeed, lTable, lVar, lScript )

//----------------------------------------------------------------------------//

#xtranslate nTrim( <x> [,<y>] [,<z>] )  =>   AllTrim( Str( <x> [,<y>] [,<z>] ) )
#xtranslate nLTrim( <x> [,<y>] [,<z>] ) =>   LTrim( Str( <x> [,<y>] [,<z>] ) )   // hb_ntos( <value> )
#xtranslate nRTrim( <x> [,<y>] [,<z>] ) =>   RTrim( Str( <x> [,<y>] [,<z>] ) )

//----------------------------------------------------------------------------//

#define CRLF        hb_OsNewLine()

//----------------------------------------------------------------------------//

#define  NONE          -2
#define  NODIV         -1
#define  CONTAINER      0
#define  FLUID          1
#define  FLEX           2
#define  COLLAPSE       3
#define  GRID           4
//#define  INLINE-FLEX   12
//#define  INLINE-GRID   14

//----------------------------------------------------------------------------//

#define TITLEANAGRAM  1
#define LINKANAGRAM   2
#define IMGANAGRAM    3
#define CLASSANAGRAM  4

//----------------------------------------------------------------------------//

#ifdef LIGHT
#define COLORMAINDIV  "lightblue"
#define COLORNAVBAR   "#AABBCC"
#define COLORTIT      "#600404"
#define COLORANAGRAM  "#800404"
#define COLORICON     "maroon"
#define COLORCARDHEAD "cadetblue"
#endif
#ifdef SLATE
#define COLORMAINDIV  "#AABBCC"
#define COLORNAVBAR   "darkslategray"
#define COLORTIT      "white"
#define COLORANAGRAM  "snow"
#define COLORICON     "snow"
#define COLORCARDHEAD "cadetblue"
#endif
#ifdef DARK
#define COLORMAINDIV  "lightblue"
#define COLORNAVBAR   "#2E2E2E"
#define COLORTIT      "#e6ee9c"
#define COLORANAGRAM  "#e6ee9c"
#define COLORICON     "#e0f2f1"
#define COLORCARDHEAD "dimgray"
#endif
#ifdef INVERSEDARK
#define COLORMAINDIV  "lightblue"
#define COLORNAVBAR   "#BDBDBD"
#define COLORTIT      "#2E2E2E"
#define COLORANAGRAM  "#2E2E2E"
#define COLORICON     "#2E2E2E"
#define COLORCARDHEAD "#999999"   //"cadetblue"
#endif
#ifdef BLACKDARK
#define COLORMAINDIV  "lightblue"
#define COLORNAVBAR   "#848484"
#define COLORTIT      "#000000"
#define COLORANAGRAM  "#000000"
#define COLORICON     "#000000"
#define COLORCARDHEAD "cadetblue"
#endif

//----------------------------------------------------------------------------//
// Commands class THtmlDoc
//----------------------------------------------------------------------------//

#xcommand CREATE DOCUMENT <oDoc> ;
          [ FILEHTML   <cFile> ] ;
          [ PROJECT <cProject> ] ;
          [ <compact: COMPACT> ] ; 
          [ <expand:  EXPAND>  ] ;
          [ SHOWHTML <bShow>   ] ; 
       => ;
          <oDoc> := THtmlDoc():New( [<cFile>], [<cProject>], [<.compact.>], ;
                                    [<.expand.>], [ \{ | Self | <bShow> \} ] )

//#xtranslate 
#xcommand DEFINE DOCUMENT <oDoc>   ;
          [ FILEHTML   <cFile>   ] ;
          [ PROJECT <cProject>   ] ;
          [ <compact: COMPACT>   ] ; 
          [ <expand:  EXPAND>    ] ;
          [ SHOWHTML <bShow>     ] ;
          [ DOCTYPE  [<oType>] [ VALUE <cTypeDoc>  ] ] ;
          [ LANGUAGE [<cLang>]   ] ;
          [ COMMENT [<uComment>], [ <lAdd: ADDCODE> ], [ <lBody: INBODY> ] ] ;
       => ;
          <oDoc> := THtmlDoc():New( [<cFile>], [<cProject>], [<.compact.>], ;
                                    [<.expand.>], [ \{ | Self | <bShow> \} ] ) ;;
          WITH OBJECT <oDoc> ;;
             :SetDoc( [<cTypeDoc>] )          ;;
             :SetLang( [<cLang>] )            ;;
             :Comment( [<uComment>], [<.lAdd.>], [<.lBody.>] ) ;;
          END

#xcommand ACTIVATE DOCUMENT <oDoc> ;
       => ;
           <oDoc>:EndDoc()

//----------------------------------------------------------------------------//

#xcommand DEFINE DOCTYPE [<oType>] [ VALUE <cStr> ] [ OF <oDoc> ] ;
       => ;
          [<oType> :=] [<oDoc>]:SetDoc( [<cStr>] )

#xcommand @ [ <cStr> ] DOCTYPE [<oType>] [ OF <oDoc> ] ;
       => ;
          [<oType> :=] [<oDoc>]:SetDoc( [<cStr>] )

#xcommand @ DOCTYPE [<oType>] [ VALUE <cStr> ] [ OF <oDoc> ] ;
       => ;
          [<oType> :=] [<oDoc>]:SetDoc( [<cStr>] )

//----------------------------------------------------------------------------//

#xcommand DEFINE LANGUAGE <cLang> [ OF <oDoc> ] ;
       => ;
          [<oDoc>]:SetLang( <cLang> )

#xcommand @ <cLang> LANGUAGE [ OF <oDoc> ] ;
       => ;
          [<oDoc>]:SetLang( <cLang> )

#xcommand @ LANGUAGE <cLang> [ OF <oDoc> ] ;
       => ;
          [<oDoc>]:SetLang( <cLang> )

//----------------------------------------------------------------------------//

#xcommand DEFINE COMMENT <uComment> ;
          [ OF <oDoc> ] ;
          [ <lAdd: ADDCODE> ] ;
          [ <lBody: INBODY> ] ;
       => ;
          [<oDoc>]:Comment( <uComment>, [<.lAdd.>], [<.lBody.>] )

#xcommand @ <uComment> COMMENT  ;
          [ OF <oDoc> ] ;
          [ <lAdd: ADDCODE> ] ;
          [ <lBody: INBODY> ] ;
       => ;
          [<oDoc>]:Comment( <uComment>, [<.lAdd.>], [<.lBody.>] )

#xcommand @ COMMENT <uComment>  ;
          [ OF <oDoc> ] ;
          [ <lAdd: ADDCODE> ] ;
          [ <lBody: INBODY> ] ;
       => ;
          [<oDoc>]:Comment( <uComment>, [<.lAdd.>], [<.lBody.>] )

//----------------------------------------------------------------------------//

#xcommand CREATE HEAD [<oHead>] ;
          [ OF <oDoc> ] ;
          [ <lAdd: ADDCODE> ] ;
       => ;
          [<oHead> :=] [<oDoc>]:SetHead( [<.lAdd.>] )

#xcommand ACTIVATE HEAD [<oHead>] [ TITLE <cTit> ] ;
          [ OF <oDoc> ] ;
          [ <lAdd: ADDCODE> ] ;
       => ;
          [<oHead> :=] [<oDoc>]:EndHead( [<cTit>], [<.lAdd.>] )

//#//xtranslate
#xcommand DEFINE HEAD [<oHead>] ;
          [ OF <oDoc> ] ;
          [ <lAdd: ADDCODE> ] ;
          [ CHARSET <cSet>       ] ;
          [ CONTENTTYPE <cType>  ] ;
          [ CONTENTLANGUAGE <cLangs> ] ;
          [ AUTHOR <cAuthor>     ] ;
          [ COPYRIGHT <cCpRight> ] ;
          [ DESCRIPTION <cDesc>  ] ;
          [ KEYWORDS <cKeyw>     ] ;
          [ ROBOTS <cRobots>     ] ;
          [ ICONDOC [<oIcon>] IMAGE <cIcon> ] ;
          [ EXPIRES <cExpire>    ] ;
          [ CACHE <cCache>       ] ;
          [ GENERATOR <cGen>     ] ;
          [ APPNAME <cApp>       ] ;
          [ REFRESH [<oRefresh>] [ REF <cRef> ] [ URL <cUrl> ] ] ;
          [ TITLE <cTitle>       ] ;
       => ;
          WITH OBJECT <oDoc> ;;
          :SetHead() ;;
             :SetCharSet( [<cSet>] ) ;;
             :SetTypeDoc( [<cType>] ) ;;
             :SetListLang( [<cLangs>] ) ;;
             :SetAuthor( [<cAuthor>] ) ;;
             :SetCopyRight( [<cCpRight>] ) ;;
             :SetDescription( [<cDesc>] ) ;;
             :SetKeywords( [<cKeyw>] ) ;;
             :SetRobots( [<cRobots>] ) ;;
             :SetIcon( [<cIcon>] ) ;;
             :SetExpires( [<cExpire>] ) ;;
             :SetCacheControl( [<cCache>] ) ;;
             :SetGenerator( [<cGen>] ) ;;
             :SetApplicationName( [<cApp>] ) ;;
             :SetRefresh( [<cRef>], [<cUrl>] ) ;;
             :EndHead( <cTitle> ) ;;
          END

//----------------------------------------------------------------------------//

#xcommand DEFINE CHARSET <cSet> [ OF <oDoc> ] ;
       => ;
          [<oDoc>]:SetCharSet( <cSet> )

#xcommand @ <cSet> CHARSET [ OF <oDoc> ] ;
       => ;
          [<oDoc>]:SetCharSet( <cSet> )

#xcommand @ CHARSET <cSet> [ OF <oDoc> ] ;
       => ;
          [<oDoc>]:SetCharSet( <cSet> )

//----------------------------------------------------------------------------//

#xcommand DEFINE CONTENTTYPE <cType> [ OF <oDoc> ] ;
       => ;
          [<oDoc>]:SetTypeDoc( <cType> )

#xcommand @ <cType> CONTENTTYPE [ OF <oDoc> ] ;
       => ;
          [<oDoc>]:SetTypeDoc( <cType> )

#xcommand @ CONTENTTYPE <cType> [ OF <oDoc> ] ;
       => ;
          [<oDoc>]:SetTypeDoc( <cType> )

//----------------------------------------------------------------------------//

#xcommand DEFINE CONTENTLANGUAGE <cLangs> [ OF <oDoc> ] ;
       => ;
          [<oDoc>]:SetListLang( <cLangs> )

#xcommand @ <cLangs> CONTENTLANGUAGE [ OF <oDoc> ] ;
       => ;
          [<oDoc>]:SetListLang( <cLangs> )

#xcommand @ CONTENTLANGUAGE <cLangs> [ OF <oDoc> ] ;
       => ;
          [<oDoc>]:SetListLang( <cLangs> )

//----------------------------------------------------------------------------//

#xcommand DEFINE AUTHOR <cAuthor> [ OF <oDoc> ] ;
       => ;
          [<oDoc>]:SetAuthor( <cAuthor> )

#xcommand @ <cAuthor> AUTHOR [ OF <oDoc> ] ;
       => ;
          [<oDoc>]:SetAuthor( <cAuthor> )

#xcommand @ AUTHOR <cAuthor> [ OF <oDoc> ] ;
       => ;
          [<oDoc>]:SetAuthor( <cAuthor> )

//----------------------------------------------------------------------------//

#xcommand DEFINE COPYRIGHT <cCpRight> [ OF <oDoc> ] ;
       => ;
          [<oDoc>]:SetCopyRight( <cCpRight> )

#xcommand @ <cCpRight> COPYRIGHT [ OF <oDoc> ] ;
       => ;
          [<oDoc>]:SetCopyRight( <cCpRight> )

#xcommand @ COPYRIGHT <cCpRight> [ OF <oDoc> ] ;
       => ;
          [<oDoc>]:SetCopyRight( <cCpRight> )

//----------------------------------------------------------------------------//

#xcommand DEFINE DESCRIPTION <cDesc> [ OF <oDoc> ] ;
       => ;
          [<oDoc>]:SetDescription( <cDesc> )

#xcommand @ <cDesc> DESCRIPTION [ OF <oDoc> ] ;
       => ;
          [<oDoc>]:SetDescription( <cDesc> )

#xcommand @ DESCRIPTION <cDesc> [ OF <oDoc> ] ;
       => ;
          [<oDoc>]:SetDescription( <cDesc> )

//----------------------------------------------------------------------------//

#xcommand DEFINE KEYWORDS <cKeyw> [ OF <oDoc> ] ;
       => ;
          [<oDoc>]:SetKeywords( <cKeyw> )

#xcommand @ <cKeyw> KEYWORDS [ OF <oDoc> ] ;
       => ;
          [<oDoc>]:SetKeywords( <cKeyw> )

#xcommand @ KEYWORDS <cKeyw> [ OF <oDoc> ] ;
       => ;
          [<oDoc>]:SetKeywords( <cKeyw> )

//----------------------------------------------------------------------------//

#xcommand DEFINE ROBOTS <cRobots> [ OF <oDoc> ] ;
       => ;
          [<oDoc>]:SetRobots( <cRobots> )

#xcommand @ <cRobots> ROBOTS [ OF <oDoc> ] ;
       => ;
          [<oDoc>]:SetRobots( <cRobots> )

#xcommand @ ROBOTS <cRobots> [ OF <oDoc> ] ;
       => ;
          [<oDoc>]:SetRobots( <cRobots> )

//----------------------------------------------------------------------------//

#xcommand DEFINE ICONDOC [<oIcon>] IMAGE <cIcon> [ OF <oDoc> ] ;
       => ;
          [<oIcon> :=] [<oDoc>]:SetIcon( <cIcon> )

#xcommand @ <cIcon> ICONDOC [<oIcon>] [ OF <oDoc> ] ;
       => ;
          [<oIcon> :=] [<oDoc>]:SetIcon( <cIcon> )

#xcommand @ ICONDOC [<oIcon>] IMAGE <cIcon> [ OF <oDoc> ] ;
       => ;
          [<oIcon> :=] [<oDoc>]:SetIcon( <cIcon> )

//----------------------------------------------------------------------------//

#xcommand DEFINE VIEWPORT [<oVPort>] [ OF <oDoc> ] ;
          [ VIEW <cVPort>] ;
          [ WIDTH <cW> ]   ;
          [ HEIGHT <cH> ]  ;
          [ SCALE <cSc> ]  ;
          [ <fit: FIT> ]   ;
      => ;
          [<oVPort> :=] [<oDoc>]:SetViewPort( [<cVPort>], [<cW>], ;
                                             [<cH>], [<cSc>], [<.fit.>] )

#xcommand @ VIEWPORT [<oVPort>] [ OF <oDoc> ] ;
          [ VIEW <cVPort>] ;
          [ WIDTH <cW> ]   ;
          [ HEIGHT <cH> ]  ;
          [ SCALE <cSc> ]  ;
          [ <fit: FIT> ]   ;
      => ;
          [<oVPort> :=] [<oDoc>]:SetViewPort( [<cVPort>], [<cW>], ;
                                             [<cH>], [<cSc>], [<.fit.>] )

//----------------------------------------------------------------------------//

#xcommand DEFINE EXPIRES <cExpire> [ OF <oDoc> ] ;
       => ;
          [<oDoc>]:SetExpires( <cExpire> )

#xcommand @ <cExpire> EXPIRES [ OF <oDoc> ] ;
       => ;
          [<oDoc>]:SetExpires( <cExpire> )

#xcommand @ EXPIRES <cExpire> [ OF <oDoc> ] ;
       => ;
          [<oDoc>]:SetExpires( <cExpire> )

//----------------------------------------------------------------------------//

#xcommand DEFINE CACHE <cCache> [ OF <oDoc> ] ;
       => ;
          [<oDoc>]:SetCacheControl( <cCache> )

#xcommand @ <cCache> CACHE [ OF <oDoc> ] ;
       => ;
          [<oDoc>]:SetCacheControl( <cCache> )

#xcommand @ CACHE <cCache> [ OF <oDoc> ] ;
       => ;
          [<oDoc>]:SetCacheControl( <cCache> )

//----------------------------------------------------------------------------//

#xcommand DEFINE REFRESH [<oRefresh>] [ REF <cRef> ] [ URL <cUrl> ] [ OF <oDoc> ] ;
       => ;
          [<oRefresh> :=] [<oDoc>]:SetRefresh( [<cRef>], [<cUrl>] )

//----------------------------------------------------------------------------//

#xcommand DEFINE GENERATOR <cGen> [ OF <oDoc> ] ;
       => ;
          [<oDoc>]:SetGenerator( <cGen> )

#xcommand @ <cGen> GENERATOR [ OF <oDoc> ] ;
       => ;
          [<oDoc>]:SetGenerator( <cGen> )

#xcommand @ GENERATOR <cGen> [ OF <oDoc> ] ;
       => ;
          [<oDoc>]:SetGenerator( <cGen> )

//----------------------------------------------------------------------------//

#xcommand DEFINE APPNAME <cApp> [ OF <oDoc> ] ;
       => ;
          [<oDoc>]:SetApplicationName( <cApp> )

#xcommand @ <cApp> APPNAME [ OF <oDoc> ] ;
       => ;
          [<oDoc>]:SetApplicationName( <cApp> )

#xcommand @ APPNAME <cApp> [ OF <oDoc> ] ;
       => ;
          [<oDoc>]:SetApplicationName( <cApp> )

//----------------------------------------------------------------------------//

#xcommand DEFINE METANAME <cMeta> CONTENT <cContent> [OPENGRAPH <cTagOG>] [ OF <oDoc> ] ;
       => ;
          [<oDoc>]:SetMetaName( <cMeta>, <cContent>, [<cTagOG>] )

#xcommand @ <cMeta> METANAME [ OF <oDoc> ] CONTENT <cContent> [OPENGRAPH <cTagOG>] ;
       => ;
          [<oDoc>]:SetMetaName( <cMeta>, <cContent>, [<cTagOG>] )

#xcommand @ METANAME <cMeta> [ OF <oDoc> ] CONTENT <cContent> [OPENGRAPH <cTagOG>] ;
       => ;
          [<oDoc>]:SetMetaName( <cMeta>, <cContent>, [<cTagOG>] )

//----------------------------------------------------------------------------//

#xcommand DEFINE METAPROPERTY <cMeta> CONTENT <cContent> OPENGRAPH <cTagOG> [ OF <oDoc> ] ;
       => ;
          [<oDoc>]:SetMetaProperty( <cMeta>, <cContent>, [<cTagOG>] )

#xcommand @ <cMeta> METAPROPERTY [ OF <oDoc> ] CONTENT <cContent> [OPENGRAPH <cTagOG>] ;
       => ;
          [<oDoc>]:SetMetaProperty( <cMeta>, <cContent>, [<cTagOG>] )

#xcommand @ METAPROPERTY <cMeta> [ OF <oDoc> ] CONTENT <cContent> [OPENGRAPH <cTagOG>] ;
       => ;
          [<oDoc>]:SetMetaProperty( <cMeta>, <cContent>, [<cTagOG>] )

//----------------------------------------------------------------------------//

#xcommand CREATE HEADTEMPLATE [<oTpl>] TITLE <cTitle> [ OF <oDoc> ] ;
       => ;
          [<oTpl> :=] [<oDoc>]:SetTplStd( <cTitle> )

//----------------------------------------------------------------------------//

#xcommand DEFINE INDENTSPACES [ <nInd> ] [ OF <oDoc> ] ;
      => ;
         [<oDoc>]:SetIndentSpaces( [<nInd>] )

#xcommand @ [ <nInd> ] INDENTSPACES [ OF <oDoc> ] ;
      => ;
         [<oDoc>]:SetIndentSpaces( [<nInd>] )

#xcommand @ INDENTSPACES [ <nInd> ] [ OF <oDoc> ] ;
      => ;
         [<oDoc>]:SetIndentSpaces( [<nInd>] )

//----------------------------------------------------------------------------//

#xcommand DEFINE INDENTCODE [ <nInd> ] [ OF <oDoc> ] ;
         [ <lAdd: ADD>   ] ;
         [ <lMin: MINUS> ] ;
      => ;
         [<oDoc>]:SetIndentCode( [<nInd>], [<.lAdd.>], [<.lMin.>] )

#xcommand @ [ <nInd> ] INDENTCODE [ OF <oDoc> ] ;
         [ <lAdd: ADD>   ] ;
         [ <lMin: MINUS> ] ;
      => ;
         [<oDoc>]:SetIndentCode( [<nInd>], [<.lAdd.>], [<.lMin.>] )

#xcommand @ INDENTCODE [ <nInd> ] [ OF <oDoc> ] ;
         [ <lAdd: ADD>   ] ;
         [ <lMin: MINUS> ] ;
      => ;
         [<oDoc>]:SetIndentCode( [<nInd>], [<.lAdd.>], [<.lMin.>] )

//----------------------------------------------------------------------------//
//
//----------------------------------------------------------------------------//



//----------------------------------------------------------------------------//
//
//----------------------------------------------------------------------------//

