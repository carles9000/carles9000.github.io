Hi !

Remember update beacon lib. 

Enjoy it ! 