//	------------------------------------------------------------------------------
//	Project.......: beacon_basic
//	Description...: Use Beacon with Mercury
//	Date..........: 29/05/2021
//	Authors.......: Carles Aubia
//	------------------------------------------------------------------------------

	{% LoadHrb( 'lib/mercury/mercury.hrb' ) %}		//	Loading MVC Mercury system
	{% LoadHrb( 'lib/beacon/beacon.hrb' ) %}		//	Loading Beacon Framework

//	------------------------------------------------------------------------------

{% MercuryRouter() %}
	
	
function main()

	InitApp()
	
return nil 	

