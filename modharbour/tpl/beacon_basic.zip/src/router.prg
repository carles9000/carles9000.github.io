#include {% MercuryInclude() %}

function InitApp()

	local oApp 			

	//	Define App

		DEFINE APP oApp 
		
		//	Cfg. routes 
			
			DEFINE ROUTE 'root'    	URL '/'      			VIEW 		 'hello.view'  					METHOD 'GET' 	OF oApp		
			DEFINE ROUTE 'version'		URL 'version' 			CONTROLLER  'version@mycontroller.prg'		METHOD 'GET' 	OF oApp
		
		
		//	Beacon Examples 
		
			DEFINE ROUTE 'beacon01'	URL 'beacon01' 			CONTROLLER  'beacon01@mycontroller.prg'	METHOD 'GET' 	OF oApp
			DEFINE ROUTE 'beacon15'	URL 'beacon15' 			CONTROLLER  'beacon15@mycontroller.prg'	METHOD 'GET' 	OF oApp
						
		INIT APP oApp	

return nil


function AppPathTmp(); 				retu AP_GetEnv( "DOCUMENT_ROOT" ) + App_Url() + '/tmp/'
function AppPathLib(); 				retu AP_GetEnv( "DOCUMENT_ROOT" ) + App_Url() + '/lib/'

function AppUrlImg(); 				retu App_Url() + '/images/'
function AppUrlLib(); 				retu App_Url() + '/lib/'