#include {% MercuryInclude() %}

function InitApp()

	local oApp 	
		
	//	Define App

		DEFINE APP oApp ;
			ON INIT MyConfig() ;
			CREDENTIALS 'mERCuRy@2021!' COOKIE 'mercury'		
		
			//	Cfg. routes 
			
			DEFINE ROUTE 'root'    	URL '/'      			VIEW 		 'hello.view'  					METHOD 'GET' 	OF oApp		
			DEFINE ROUTE 'version'		URL 'version' 			CONTROLLER  'version@mycontroller.prg'	METHOD 'GET' 	OF oApp
			DEFINE ROUTE 'beacon01'	URL 'beacon01' 			CONTROLLER  'beacon01@mycontroller.prg'	METHOD 'GET' 	OF oApp
						
		INIT APP oApp	

return nil


function AppPathData(); 			retu AP_GetEnv( "DOCUMENT_ROOT" ) + AP_GetEnv( "PATH_DATA" )
function AppPathTmp(); 				retu AP_GetEnv( "DOCUMENT_ROOT" ) + AP_GetEnv( "PATH_APP" ) + '/tmp/'
function AppPathLib(); 				retu AP_GetEnv( "DOCUMENT_ROOT" ) + AP_GetEnv( "PATH_APP" ) + '/lib/'

function AppUrlImg(); 				retu AP_GetEnv( "PATH_APP" ) + '/images/'
function AppUrlLib(); 				retu AP_GetEnv( "PATH_APP" ) + '/lib/'
function AppUrlTmp(); 				retu AP_GetEnv( "PATH_APP" ) + '/tmp/'

function MyConfig() 

	SET DELETED ON
	SET DATE TO ITALIAN	
	SET CENTURY on	
	
retu nil

