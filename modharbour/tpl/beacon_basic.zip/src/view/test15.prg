//----------------------------------------------------------------------------//
//
// Author: ( c ) Cristobal Navarro Lopez
// Date  : 30/06/2020
// Sample for use BEACON Framework for Web Programming with Mod-Harbour ( c )
// BEACON - ( c ) Cristobal Navarro
//
//----------------------------------------------------------------------------//
//
// Test14.Prg
//
//----------------------------------------------------------------------------//
//
// Load library with all classes and functions
// {%  LoadHRB( '../src/beacon.hrb' )  %} 
// {% include( "/beacon/include/beacon.ch" )  %}
//
//----------------------------------------------------------------------------//

#ifdef FEMOD
#include "C:\XAMPP\HTDOCS\BEACON\include\beacon.ch"
#endif

//----------------------------------------------------------------------------//

Function Main()
   local oMain
   local oBody
   local oElement
   local oImg
   local oH1
   local oForm
   local oLabel1
   local oLabel2
   local oInput1
   local oInput2
   local oInput3
   local oA1
   local oA2
   local oRow
   local cCsp   := ""
   local nInd   := 3

   SET CENTURY ON
   SET DATE TO BRITISH

   oMain := THtmlDoc():New()    // , "Demo1" )
   WITH OBJECT oMain
      //:SetIndentSpaces( nInd )
      :SetLang( "es" )
      :SetDoc()

      :SetIndentCode( nInd, .T., .F. )
      :SetHead()
         :SetAddCodetoView( .T. )    // Activa el uso de views

         :SetCharSet( "utf-8" )
         :SetTypeDoc( "text/html" )
         :SetAuthor( "Cristobal Navarro Lopez" )
         :SetCopyRight( "(C) CNL" )
         :SetDescription( "Beacon Login Standard" )
         :SetKeyWords( "harbour,beacon,mod_harbour" )
         :SetRobots( "" )        // "noindex,nofollow" )
         :SetIcon( ".." + hb_ps() + "images" + hb_ps() + "favicon.png" )

         :SetTplStd( "Beacon" )
         //:SetIndentCode( nInd, .F., .T. )
         :SetView( "head15.view",  )
      :EndHead()
      :SetIndentCode( nInd, .F., .T. )

      // Grabar en view

      :SetIndentCode( nInd, .T., .F. )

      oBody := TBody():New( , oMain, , )
         WITH OBJECT oBody
            //:SetDebug( .T. )
            :SetHeight( "100%" )
            :SetFamFont( "Roboto" )
            :SetSizeFont( 12 ) //"12vh" )
            //:SetFont( "Roboto", "100vh", , .F. )
            :SetBackGround( 'url("../images/Lake.jpg") no-repeat center top', "cover" )
            :Activate( "xbody" )
            //:End()
         END

         // Empecemos con <DIV>
         oMain:SetIndentCode( nInd, .T., .F.)
         oElement  := TDiv():New( , oMain, , oBody )
         WITH OBJECT oElement
            :SetWidth( 360 )
            :SetHeight( 460 )
            :SetTop( "50%" )
            :SetLeft( "50%" )
            :SetPosition( "absolute" )
            :SetColor( "#FFF", "#000E" )
            :SetPaddingTop( 70,  )
            :SetPaddingBottom( 70,  )
            :SetPaddingLeft( 30 )
            :SetPaddingRight( 30 )
            :SetKeyStyles( { { "transform", "translate(-50%, -50%)" }, { "box-sizing", "border-box"} } )
            
            //:SetBorder( "solid", 2, "blue", , , ) //cStyle, nW, cClr, cUni, nBord, nRad )

            :Activate( "main" )

             oMain:SetIndentCode( nInd, .T., .F. )
             oImg  := TBImage():New( , oMain, , oElement )
             WITH OBJECT oImg
                :SetImage( ".." + hb_ps() + "images" + hb_ps() + "harbmod9.png" )
                :SetKeyStyles( { { "--img-height", "10vh" } } )
                :SetHeight( "var(--img-height)" )
                :SetWidth( "var(--img-height)" )
                :SetPosition( "absolute" )
                :SetTop( -50 )
                :SetLeft( "calc(50% - var(--img-height)/2)" )
                :SetBorder( , , , , , "10%" ) //cStyle, nW, cClr, cUni, nBord, nRad )
                :Activate( "image" )
             END

             oH1  := THAttrib():New( , oMain, , oElement )
             WITH OBJECT oH1
                :SetCaption( "Login Here" )
                :SetSize( "1" )                // <h1
                :SetFamFont( "sans-serif" )
                :SetSizeFont( 24 )
                :SetPaddingTop( 0 )
                :SetPaddingBottom( 0 )
                :SetPaddingLeft( 20 )
                :SetPaddingRight( 20 )
                :SetTextAlign( "center" )

                :Activate( "h1" )
             END
             //:SetDebug( .F. )

             //New( lCompact, oDoc, cIdP, oP, cClass, nType, cMethod, uAction )
             oForm       := TBForm():New( , oMain, , oElement )
             WITH OBJECT oForm
                :SetMarginTop( 20 )
                :SetWidth( "100%" )
                :SetMarginBottom( 20 )
                //:SetBorder( "solid", 1, "red", , , ) //cStyle, nW, cClr, cUni, nBord, nRad )

                //Activate( cClass, cId, lAdd, lInline, lHoriz )
                :Activate( , , , , )

                oMain:SetIndentCode( nInd, .T., .F. )
                oLabel1  := TLabel():New( , oMain, , oForm )
                WITH OBJECT oLabel1
                   //:SetFamFont( "Kalam" ) //"Courgette" )
                   :SetSizeFont( 2.6, "vh" )
                   :SetWeightFont( "bold" )
                   :SetDisplay( "block" )
                   :SetColor( , "transparent" )   // ==>  :SetColor( , oForm:cBackColor )
                   //:SetForId( "input1" )
                   //Activate( cClass, cId, lAdd, cLabel, cFor )
                   :Activate( , , , "Username", "input1" )
                END

                oInput1  := TInput():New( , oMain, , oForm )
                WITH OBJECT oInput1
                   :SetSizeFont( 2.5, "vh" )
                   :SetMarginTop( 5 )
                   :SetMarginBottom( 20 )
                   :SetDisplay( "block" )
                   :SetColor( "#FFF", "transparent" ) // ==>    //:SetColor( , oForm:cBackColor )
                   :SetWidth( "100%" )
                   :SetHeight( 40 )
                   :SetBorder( "solid", 1, "#FFF", "px", 3,  )
                   //SetOutLine( cStyle, nW, cClr, cUni, nOffset )
                   :SetOutLine( "none", , , , )
                   :SetTypeInput( "text" )
                   :SetCueBanner( "Enter UserName" )
                   :SetName( "input1" )
                   :Activate( "input1", , , , , , , )
                   //Activate( cClass, cId, lAdd, uValue, lReadOnly, lDisable, uSize, nMaxLength )
                END

                oLabel2  := TLabel():New( , oMain, , oForm )
                WITH OBJECT oLabel2
                   :SetKeyStyles( oLabel1:SetKeyStyles() )
                   :Activate( , , , "Password", "input2" )
                END

                oInput2  := TInput():New( , oMain, , oForm )
                WITH OBJECT oInput2
                   :SetKeyStyles( oInput1:SetKeyStyles() )
                   :SetTypeInput( "password" )
                   :SetCueBanner( "Enter Password" )
                   :SetName( "input2" )
                   :Activate( "input2", , , , , , , )
                END

                oInput3  := TInput():New( , oMain, , oForm )
                WITH OBJECT oInput3
                   :SetSizeFont( 18 )
                   :SetColor( "#FFF", "#b80f22" ) // ==>    //:SetColor( , oForm:cBackColor )
                   :SetWidth( "100%" )
                   :SetHeight( 40 )
                   :SetMarginTop( 10 )
                   :SetBorder( "none", 1, , , , "20px" )
                   :SetOutLine( "none", , , , )
                   :SetDisplay( "block" )
                   :SetTypeInput( "submit" )
                   :SetName( "input3" )
                   :SetKeyEvents( { { "onmouseover", '"this.style.background=' + "'#ffc107';" + ;
                                                     " this.style.color='black';" + ;
                                                     " this.style.cursor='pointer'" + '"' }, ;
                                    { "onmouseout" , '"this.style.background=' + "'#b80f22';" + ;
                                                     " this.style.color='#FFF';" + ;
                                                     " this.style.cursor='default'" + '"' } } )
                   //:SetValue( "Log In" )
                   :Activate( "input3", , , "Log In", , , , )
                END

                oA1  := TAAttrib():New( , oMain, , oForm )
                WITH OBJECT oA1
                   :SetCaption( "Lost your Password?" )
                   :SetHRef( "#" )
                   :SetColor( "darkgrey", "transparent" )
                //   :SetFamFont( "sans-serif" )
                   :SetSizeFont( 14 )
                   :SetLineHeight( 20 )
                   :SetDisplay( "block" )
                   :SetPaddingTop( 20 )
                   :SetTextDecoration( , "none" )
                   :SetKeyEvents( { { "onmouseover", '"this.style.color=' + "'red'" + '"' }, ;
                                    { "onmouseout", '"this.style.color=' + "'darkgrey'" + '"' } } )

                   :Activate( "a1" )
                END

                oA2  := TAAttrib():New( , oMain, , oForm )
                WITH OBJECT oA2
                   :SetCaption( "Don't have An account?" )
                   :SetHRef( "#" )
                   :SetColor( "darkgrey", "transparent" )
                   //   :SetFamFont( "sans-serif" )
                   :SetSizeFont( 14 )
                   :SetLineHeight( 20 )
                   :SetDisplay( "block" )
                   :SetPaddingTop( 10 )
                   :SetTextDecoration( , "none" )
                   :SetKeyEvents( oA1:SetKeyEvents() )

                   :Activate( "a2" )
                END

                oMain:SetIndentCode( nInd, .F., .T. )
                :EndForm()
             END
             oMain:SetIndentCode( nInd, .F., .T. )

            //BFooter( oMain, oElement, nInd )

            :EndDiv()
         END

         :SetIndentCode( nInd, .F., .T.)
      :EndBody( .T. )

      :SetIndentCode( nInd, .F., .T. )
      //:SetTemplate( "Demo1" )
      :EndDoc()
   END
   //ModLog( "End of " + AP_FileName() )

Return nil

//----------------------------------------------------------------------------//
//
//----------------------------------------------------------------------------//
#ifdef FEMOD
#include "C:\XAMPP\HTDOCS\BEACON\SRC\BEACON.PRG"
#endif
//----------------------------------------------------------------------------//
