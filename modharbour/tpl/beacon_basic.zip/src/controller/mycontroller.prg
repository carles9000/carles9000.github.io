#include {% MercuryInclude() %}
#include "{% AppPathLib() + 'beacon/beacon.ch' %}"	

CLASS MyController

	METHOD New( oController )			CONSTRUCTOR

	METHOD Version( oController )			
	METHOD Beacon01( oController )				
		
ENDCLASS   

//----------------------------------------------------------------------------//

METHOD New( oController ) CLASS MyController
	

RETU Self 

//----------------------------------------------------------------------------//

METHOD Version( oController ) CLASS MyController	

	oController:View( 'version.view' )

RETU nil

//----------------------------------------------------------------------------//

METHOD Beacon01( oController ) CLASS MyController	

	local hData := {=>}
	
	//	Recolecto y proceso datos
	
		hData[ 'mercuryversion'] 	:= MercuryVersion()
		hData[ 'time' ] 			:= time()
		hData[ 'date' ] 			:= date()
		hData[ 'name' ] 			:= 'Paul Britman'
		
	//	Llamo a la vista y que pinte los datos que le paso

		oController:View( 'beacon01.view', hData )

RETU nil


//----------------------------------------------------------------------------//
