#include {% MercuryInclude( 'lib/mercury' ) %}

CLASS Browse_Pag

	METHOD New( oController )			CONSTRUCTOR

	METHOD Show( oController )											
	METHOD Load( oController )					
				
		
ENDCLASS   

//----------------------------------------------------------------------------//

METHOD New( oController ) CLASS Browse_Pag

	
RETU Self 

//----------------------------------------------------------------------------//

METHOD Show( oController ) CLASS Browse_Pag			

	oController:View( 'browse/browse_pag.view' )						 			
	
RETU nil

//----------------------------------------------------------------------------//


METHOD Load( oController ) CLASS Browse_Pag

	local oTest 		:= TestModel():New()
	local cAlias 		:= oTest:cAlias
	local nOffset 		:= oController:GetValue( 'offset',nil, 'N' )
	local nLimit 		:= oController:GetValue( 'limit', nil, 'N' )
	local n 			:= 0
	local nTotal 	
	local aRows     	:= {}
	local dat 			:= {=>}	

	//	Important because we're use ajax and special chars
	
		oTest:lLoadAnsiToUtf8 	:= .t.	
		
	//	--------------------------------------------------
	
	nOffset := if( nOffset == 0, 1, nOffset )	
	
	(cAlias)->( OrdSetFocus( 'FIRST' ) )
		
	(cAlias)->( OrdKeyGoto( nOffset ) )	

	//	Process data...
	
		WHILE  n < nLimit .and. (cAlias)->( !Eof() ) 
		
			n++			

			hRow 				:=  oTest:Load( { 'first', 'last', 'street' } )
			
			hRow[ '_keyno' ]	:= (cAlias)->(OrdKeyNo())		
			
			Aadd( aRows, hRow )							
		
			(cAlias)->( DbSkip() )
			
		END				

	//	-----------------------------------------------------
	//	Debemos devolver un hash con 3 keys
	//	total				-> Total registros filtrados, no paginados
	//	totalNotFiltered 	-> Total registros tabla
	//	rows				-> Array de hashes de cada registro 
	//	-----------------------------------------------------
	
		COUNT TO nTotal

		dat[ 'total' ] 				:= (cAlias)->( ordKeyCount() )	
		dat[ 'totalNotFiltered' ] 	:= nTotal
		dat[ 'rows' ] 				:= aRows		
	
	//	Response...
	
		oController:oResponse:SendJson(  dat )	

RETU nil

//----------------------------------------------------------------------------//

{% LoadFile( "/src/model/testmodel.prg" ) %}