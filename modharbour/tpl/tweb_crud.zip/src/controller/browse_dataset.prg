#include {% MercuryInclude( 'lib/mercury' ) %}

CLASS Browse_Dataset

	METHOD New( oController )			CONSTRUCTOR

	METHOD Show( oController )											
	METHOD Load( oController )					
	METHOD Save( oController )					
		
ENDCLASS   

//----------------------------------------------------------------------------//

METHOD New( oController ) CLASS Browse_Dataset

	
RETU Self 

//----------------------------------------------------------------------------//

METHOD Show( oController ) CLASS Browse_Dataset			

	oController:View( 'browse/browse_dataset.view' )						 			
	
RETU nil

//----------------------------------------------------------------------------//


METHOD Load( oController ) CLASS Browse_Dataset

	local oDataset		:= OpenDatasetCusto()
	local cAlias 		:= oDataset:Alias()
	local aRows     	:= {}
	
	oDataset:lLoadAnsiToUtf8 	:= .t.

	//	Process data...
	
		WHILE (cAlias)->( !Eof() )
		
			Aadd( aRows, oDataset:Row() )
		
			(cAlias)->( DbSkip() )
		END		
	
	//	Response...
	
		oController:oResponse:SendJson(  { 'rows' => aRows } )

RETU nil

//----------------------------------------------------------------------------//


METHOD Save( oController ) CLASS Browse_Dataset

	local hParam 			:= GetMsgServer()
	local aData 			:= hParam[ 'data' ]
	local oCusto			:= OpenDatasetCusto()
	local aDataChanged 


	//	Save Rows
	
	/*
		Method Save() of dataset return array with rows that processed.
		Every element have newxt structure
		
		{ 
			success	-> .t./.f.
			id 			-> uniqueid 
			action 	-> A/U/D	(Add/Update/Delete)
			item		-> hash of row after processed 
			msg 		-> message 		
		}

	*/
		aDataChanged 		:= oCusto:Save( aData )		
		
	//	Response
		
		oController:oResponse:SendJson( { 'datachanged' => aDataChanged } )	
	
RETU nil 

//----------------------------------------------------------------------------//

{% LoadFile( "/src/model/datasetcusto.prg" ) %}