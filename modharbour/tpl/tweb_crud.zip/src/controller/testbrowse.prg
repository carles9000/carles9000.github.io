#include {% MercuryInclude( 'lib/mercury' ) %}

CLASS TestBrowse

	METHOD New( oController )			CONSTRUCTOR

	METHOD Browse_Basic( oController )						
					
	METHOD SaveData( oController )						
		
ENDCLASS   

//----------------------------------------------------------------------------//

METHOD New( oController ) CLASS TestBrowse

	
RETU Self 

//----------------------------------------------------------------------------//

METHOD SaveData( oController ) CLASS TestBrowse	

	local hParam 	:= GetMsgServer()
	local aRows 	:= hParam[ 'rows' ]
	local oTest 	:= TestModel():New()	
	local nChanges	:= len(aRows )
	local aProcess := {}
	local n, hRow, cAction, nId, hData, cMsg
	local lOk 
	
	/*
		We receive from browse.view un object with 'rows' key and is a array of rows changed. 
		The structure of every elements is a hash:
		action -> A/D/U	(Add/Delete/Update)
		id		-> uniqueid of browse
		row 	-> hash fields row		
		
		You can see value with
		
		_d( hParam )
	*/
	
	SET DATE FORMAT TO 'DD-MM-YY'
	
	//	This is the basic concept to update dbf. You can do your function more optimized
	//	Este es el concepto básico para actualizar el dbf. Puedes hacer una funcion mas optimizada
	
	for n := 1 to nChanges 
	
		cAction 	:= upper( aRows[n][ 'action' ] )
		nId 		:= aRows[n][ 'id' ] 
		hRow 		:= aRows[n][ 'row' ]
		cMsg 		:= ''
		lOk 		:= .f.
	
		HB_HCaseMatch( hRow, .f. )
	
		do case
			case cAction  == 'U' 	//	Update
			
				hData := {=>}
				hData[ 'first' ] 	:= hRow[ 'FIRST' ] 
				hData[ 'last'  ] 	:= hRow[ 'LAST' ] 
				hData[ 'street'] 	:= hRow[ 'STREET' ] 
				hData[ 'state' ] 	:= hRow[ 'STATE' ] 
				hData[ 'zip'   ] 	:= hRow[ 'ZIP' ] 
				hData[ 'hiredate' ]	:= CToD( hRow[ 'HIREDATE' ] )
				hData[ 'married' ] 	:= hRow[ 'MARRIED' ]
				hData[ 'age' ] 		:= hRow[ 'AGE' ]
				hData[ 'salary' ] 	:= hRow[ 'SALARY' ]
				hData[ 'notes' ] 	:= hRow[ 'NOTES' ]
				
				if hRow[ 'FIRST'] == 'BAD'
					cMsg := 'Name first not allowed (BAD)'
				else 
			
					lOk := oTest:Update( nId, hData )
					
					if !lOk
						cMsg := 'Error updating ' + ltrim(str( nId ) )
					endif
				
				endif
				
				
			case cAction  == 'D' 	//	Delete
			
				lOk := oTest:Delete( nId )
				
				if !lOk
					cMsg := 'Error deleting ' + ltrim(str(nId))
				endif
				
			case cAction  == 'A' 	//	Add
			
				hData := {=>}
				hData[ 'first' ] 	:= hRow[ 'FIRST' ] 
				hData[ 'last'  ] 	:= hRow[ 'LAST' ] 
				hData[ 'street'] 	:= hRow[ 'STREET' ] 
				hData[ 'state' ] 	:= hRow[ 'STATE' ] 
				hData[ 'zip'   ] 	:= hRow[ 'ZIP' ] 
				hData[ 'hiredate' ]	:= CToD( hRow[ 'HIREDATE' ] )
				hData[ 'married' ] 	:= hRow[ 'MARRIED' ]
				hData[ 'age' ] 		:= hRow[ 'AGE' ]
				hData[ 'salary' ] 	:= 0 	//	hRow[ 'SALARY' ]
				hData[ 'notes' ] 	:= hRow[ 'NOTES' ]			
			
				lOk := oTest:Add( hData ) 									
				
				if !lOk
					cMsg := 'Error new record '
				endif
			
		endcase 
		
		if lOk 
			Aadd( aProcess, { 'success' => lOk, 'id' => nId, 'action' => cAction, 'item' => oTest:Load(), 'msg' => cMsg } )
		else
			Aadd( aProcess, { 'success' => lOk, 'id' => nId, 'action' => cAction, 'item' => nil, 'msg' => cMsg } )
		endif
		
		
	next 
	
	oController:oResponse:SendJson( { 'datachanged' => aProcess })

retu nil 

//----------------------------------------------------------------------------//

METHOD Browse_Basic( oController ) CLASS TestBrowse	

	local oTest := TestModel():New()
	local aRows := oTest:LoadRows()		
	
	oController:View( 'browse/browse_basic.view', aRows )						 			
	
RETU nil

//----------------------------------------------------------------------------//

{% LoadFile( "/src/model/testmodel.prg" ) %}