#include {% MercuryInclude( 'lib/mercury' ) %}

CLASS Browse_Basic

	METHOD New( oController )			CONSTRUCTOR

	METHOD Show( oController )													
	METHOD Save( oController )						
		
ENDCLASS   

//----------------------------------------------------------------------------//

METHOD New( oController ) CLASS Browse_Basic

	
RETU Self 

//----------------------------------------------------------------------------//

METHOD Show( oController ) CLASS Browse_Basic	

	local oTest := TestModel():New()
	local aRows 
	
	/*
		This property is very important. Dbf managment is a few sensible. You can 
		see tweb doc about it.
		
		The most important is:
			-	Data are normally saved in ansi format. For default, tdbf class load and
				convert data to utf8 format. Then you need charset utf-8 defined in your 
				web page.
				
			-	If you want use ISO charset in your web page then you need block convert data 
			
				::lLoadAnsiToUtf8 := .f.  	//	Default is .T.
				
			- 	If you need ajax conections, then use default value -> ::lLoadAnsiToUtf8 := .t.
				
		In our case, we defined charset ISO-8859-1
	*/	
	

	oTest:lLoadAnsiToUtf8 	:= .f.	
	
	//	Load all Rows 
	
		aRows := oTest:LoadRows()
		
	//	Response. Init view and send rows 
	
		oController:View( 'browse/browse_basic.view', aRows )						 			
	
RETU nil

//----------------------------------------------------------------------------//

METHOD Save( oController ) CLASS Browse_Basic	

	local hParam 	:= GetMsgServer()
	local aRows 	:= hParam[ 'rows' ]
	local oTest 	:= TestModel():New()	
	local nChanges	:= len(aRows )
	local aProcess := {}
	local n, hRow, cAction, nId, hData, cMsg
	local lOk 
	local cAlias 

	
	/*
		We receive from browse.view un object with 'rows' key and is a array of rows changed. 
		The structure of every elements is a hash:
		action -> A/D/U	(Add/Delete/Update)
		id		-> uniqueid of browse
		row 	-> hash fields row		
		
		You can see value with
		
		_d( hParam )
	*/
	
	SET DATE FORMAT TO 'DD-MM-YY'
	
	//	This is the basic concept to update dbf. You can do your function more optimized
	//	Este es el concepto b�sico para actualizar el dbf. Puedes hacer una funcion mas optimizada
	
	for n := 1 to nChanges 
	
		cAction 	:= upper( aRows[n][ 'action' ] )
		nId 		:= aRows[n][ 'id' ] 
		hRow 		:= aRows[n][ 'row' ]
		cMsg 		:= ''
		lOk 		:= .f.
	
		HB_HCaseMatch( hRow, .f. )
	
		do case
			case cAction  == 'U' 	//	Update
			
				hData := {=>}
				hData[ 'first' ] 		:= hRow[ 'FIRST' ] 
				hData[ 'last'  ] 		:= hRow[ 'LAST' ] 
				hData[ 'street'] 		:= hRow[ 'STREET' ] 
				hData[ 'state' ] 		:= hRow[ 'STATE' ] 
				hData[ 'zip'   ] 		:= hRow[ 'ZIP' ] 
				hData[ 'hiredate' ]	:= CToD( hRow[ 'HIREDATE' ] )
				hData[ 'married' ] 	:= hRow[ 'MARRIED' ]
				hData[ 'age' ] 		:= hRow[ 'AGE' ]
				hData[ 'salary' ] 		:= hRow[ 'SALARY' ]
				hData[ 'notes' ] 		:= hRow[ 'NOTES' ]															
				
				//	Control exemple -------------------------------------------
				//	Check First !== 'BAD' -------------------------------------
				
					if hRow[ 'FIRST'] == 'BAD'
						cMsg := 'Name first not allowed (BAD)'
					else 
				
						lOk := oTest:Update( nId, hData )
						
						if !lOk
							cMsg := 'Error updating ' + ltrim(str( nId ) )
						endif
					
					endif
				
				//	-----------------------------------------------------------
				
				
			case cAction  == 'D' 	//	Delete
			
				lOk := oTest:Delete( nId )
				
				if !lOk
					cMsg := 'Error deleting ' + ltrim(str(nId))
				endif
				
			case cAction  == 'A' 	//	Add
			
				hData := {=>}
				hData[ 'first' ] 		:= hRow[ 'FIRST' ] 
				hData[ 'last'  ] 		:= hRow[ 'LAST' ] 
				hData[ 'street'] 		:= hRow[ 'STREET' ] 
				hData[ 'state' ] 		:= hRow[ 'STATE' ] 
				hData[ 'zip'   ] 		:= hRow[ 'ZIP' ] 
				hData[ 'hiredate' ]	:= CToD( hRow[ 'HIREDATE' ] )
				hData[ 'married' ] 	:= hRow[ 'MARRIED' ]
				hData[ 'age' ] 		:= hRow[ 'AGE' ]
				hData[ 'salary' ] 		:= 0 	//	hRow[ 'SALARY' ]
				hData[ 'notes' ] 		:= hRow[ 'NOTES' ]			
			
				lOk := oTest:Add( hData ) 									
				
				if !lOk
					cMsg := 'Error new record '
				endif
			
		endcase 
		
		/*
			We'll response with an array an every element with this structure:
			success 	-> true/false operation
			id			-> id browse
			action 	-> A/D/U	(Add/Delete/Update)
			item		-> Refresh item. This item will be replaced into browse 
			msg			-> Default empty. 
		*/

		
		Aadd( aProcess, {  'success' 	=> lOk, ;
							'id' 		=> nId,;
							'action' 	=> cAction,;
							'item' 		=> if( lOk, oTest:Load(), nil ),;
							'msg' 		=> cMsg } )
		
		
	next 
	
	oController:oResponse:SendJson( { 'datachanged' => aProcess })

retu nil 



//----------------------------------------------------------------------------//

{% LoadFile( "/src/model/testmodel.prg" ) %}