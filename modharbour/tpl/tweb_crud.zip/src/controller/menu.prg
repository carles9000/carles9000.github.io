#include {% MercuryInclude( 'lib/mercury' ) %}

CLASS Menu

	METHOD New( oController )			CONSTRUCTOR

	METHOD Main( oController )			
	
		
ENDCLASS   

//----------------------------------------------------------------------------//

METHOD New( oController ) CLASS Menu	

RETU Self 

//----------------------------------------------------------------------------//

METHOD Main( oController ) CLASS Menu	

	oController:View( 'main.view', 'charly', 'Charly Aubia' )

RETU nil


//----------------------------------------------------------------------------//
