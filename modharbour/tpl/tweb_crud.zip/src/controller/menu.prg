#include {% MercuryInclude( 'lib/mercury' ) %}

CLASS Menu

	METHOD New( oController )			CONSTRUCTOR

	METHOD Main( oController )			
	
		
ENDCLASS   

//----------------------------------------------------------------------------//

METHOD New( oController ) CLASS Menu	

RETU Self 

//----------------------------------------------------------------------------//

METHOD Main( oController ) CLASS Menu	

	local hData := {=>}

	GET JWT hData OF oController

	oController:View( 'main.view', 'charly', 'Charly Aubia' )

RETU nil


//----------------------------------------------------------------------------//
