#include {% MercuryInclude() %}


function InitApp()

	local oApp 	
		
	//	Define App

		DEFINE APP oApp ON INIT MyConfig() 
		
		//	Config Routes									
			
			DEFINE ROUTE 'root'			URL '/'  			VIEW 		'hello.view'  		METHOD 'GET' 	OF oApp		
			DEFINE ROUTE 'main'			URL 'main'			CONTROLLER  'main@menu.prg' 	METHOD 'GET' 	OF oApp

			DEFINE ROUTE 'savedata'		URL 'savedata'		CONTROLLER  'savedata@testbrowse.prg' 		METHOD 'POST' 	OF oApp			
			DEFINE ROUTE 'browse_basic' 	URL 'browse_basic'	CONTROLLER  'browse_basic@testbrowse.prg' 	METHOD 'GET' 	OF oApp			
			
			DEFINE ROUTE 'proc2' 			URL 'proc2'			CONTROLLER  'proc2@process.prg' METHOD 'GET' 	OF oApp			
			DEFINE ROUTE 'proc3' 			URL 'proc3'			CONTROLLER  'proc3@process.prg' METHOD 'GET' 	OF oApp			

		INIT APP oApp	

return nil

//	Path absoluto / absolute path

function AppPathData(); 			retu AP_GetEnv( "DOCUMENT_ROOT" ) + App_Url() + '/data/'

function AppUrlImg(); 			retu App_Url() + '/images/'
function AppUrlLib(); 			retu App_Url() + '/lib/'
function AppIniMenu(); 			retu 'basic_menu'


function MyConfig() 

	SET DELETED ON
	
retu nil

