#include {% MercuryInclude() %}

function InitApp()

	local oApp 	
		
	//	Define App

		DEFINE APP oApp ON INIT MyConfig() 
		
		//	Config Routes									
			
			DEFINE ROUTE 'root'			URL '/'  				VIEW 		 'hello.view'  		METHOD 'GET' 	OF oApp		
			DEFINE ROUTE 'main'			URL 'main'				CONTROLLER  'main@menu.prg' 	METHOD 'GET' 	OF oApp
			
		//	Basic Browse example

			DEFINE ROUTE 'browse_basic' 	URL 'browse_basic'		CONTROLLER  'show@browse_basic.prg' 	METHOD 'GET' 	OF oApp			
			DEFINE ROUTE 'bb_save'			URL 'bb_save'			CONTROLLER  'save@browse_basic.prg' 	METHOD 'POST' 	OF oApp			
			
		//	Browse with dataset
		
			DEFINE ROUTE 'browse_dataset' 	URL 'browse_dataset'	CONTROLLER  'show@browse_dataset.prg' 	METHOD 'GET' 	OF oApp			
			DEFINE ROUTE 'bd_load'			URL 'bd_load'			CONTROLLER  'load@browse_dataset.prg' 	METHOD 'POST' 	OF oApp			
			DEFINE ROUTE 'bd_save'			URL 'bd_save'			CONTROLLER  'save@browse_dataset.prg' 	METHOD 'POST' 	OF oApp				

		INIT APP oApp	

return nil

//	Path absoluto / absolute path

function AppPathData(); 			retu AP_GetEnv( "DOCUMENT_ROOT" ) + App_Url() + '/data/'

function AppUrlImg(); 			retu App_Url() + '/images/'
function AppUrlLib(); 			retu App_Url() + '/lib/'
function AppIniMenu(); 			retu 'basic_menu'


function MyConfig() 

	SET DELETED ON
	
retu nil

