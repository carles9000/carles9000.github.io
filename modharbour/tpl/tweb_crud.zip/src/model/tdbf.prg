//	Esta clase es solo un simple ejemplo, para crear nuestros modelos
//	Tu puedes usar las clases que mas se adapten a tus propositos
//----------------------------------------------------------------------------//
//	This class is just a simple example, to create our models
//	You can use the classes that best suit your purposes

//	Basicamente podr� abrir nuestra tabla, cambiar tag de indice y cargar un registro
//	Basically you can opening our table, changing the index tag and loading a record

#DEFINE UTYPE_ANSI          1  // ANSI

CLASS TDbf

	DATA cAlias 				INIT ''
	DATA lLoadAnsiToUtf8		INIT .t.
	DATA lSaveUtf8ToAnsi		INIT .t.		

	METHOD New()				CONSTRUCTOR
	
	METHOD Open()		
	METHOD Focus( cFocus )	INLINE (::cAlias)->( OrdSetFocus( cFocus ) )
	METHOD Count()				INLINE (::cAlias)->( RecCount() )

	METHOD Load()
	METHOD LoadRows( nRows )
	
	METHOD Update( nId, hRow )
	METHOD Delete( nId )
	METHOD Add( hRow )
		
ENDCLASS   

//----------------------------------------------------------------------------//

METHOD New() CLASS TDbf

	

RETURN Self 

//----------------------------------------------------------------------------//

METHOD Open( cDbf, cCdx, cTag ) CLASS TDbf

	local cAlias := 'A' + ltrim(str( hb_milliseconds() ))
	
	DEFAULT cTag TO ''
	
	
	

	USE ( cDbf ) SHARED NEW ALIAS &(cAlias) VIA 'DBFCDX'
	SET INDEX TO ( cCdx )
	
	::cAlias := Alias()	
	
	if !empty( cTag )
		(::cAlias)->( OrdSetFocus( cTag ) )
	else
		(::cAlias)->( OrdSetFocus( 0 ) )
	endif
	
	
	

RETU ::cAlias


//----------------------------------------------------------------------------//

METHOD Load( aFields, cAlias ) CLASS TDbf

	local hRow := {=>}
	local nI
	local nFields, uValue, cField, cType
	local lAllFields := .F.

	DEFAULT aFields TO {}
	DEFAULT cAlias TO ::cAlias
	
	
	//	Si no pasamos aFields, cargamos todos los campos...
	
	if empty( aFields ) 	
		nFields 	:= (cAlias)->( FCount() )
		lAllFields := .T.
	else	
		nFields := len( aFields )
	endif			
	
	hRow[ '_recno' ] 	:= (cAlias)->( Recno() )
	
	for nI := 1 to nFields
	
		if lAllFields 
			cField := (cAlias)->( FieldName(nI) )
			uValue := (cAlias)->( FieldGet(nI))
		else
			cField := upper( aFields[nI] )
			uValue := (cAlias)->( FieldGet( FieldPos( cField ) ) )
		endif				
		
		cType  := Valtype( uValue )
		
		do case		
			case cType == 'C' 			
			
				uValue := UHtmlEncode( alltrim(uValue) )								
				
				if ::lLoadAnsiToUtf8
					uValue := UNITOU8( uValue, UTYPE_ANSI )
				endif
			
			case cType == 'D' ; uValue := DToC( uValue )			
		endcase		
	
		hRow[ cField ] := uValue
	
	next

retu hRow 	


//----------------------------------------------------------------------------//

METHOD LoadRows( nRows ) CLASS TDbf

	local aRows := {}
	local n 	:= 0

	DEFAULT nRows TO (::cAlias)->( RecCount() )
	
	(::cAlias)->( DbGoTop() )
	
	while n <= nRows .and. (::cAlias)->( !eof() )
	
		n++
		
		Aadd( aRows, ::Load() )
		
		(::cAlias)->( DbSkip() )
	end
	
	
retu aRows 



//----------------------------------------------------------------------------//

METHOD Update( nId, hRow ) CLASS TDbf

	local lOk 	:= .f.
	local n, aPair, cField, uValue, nPos 

	DEFAULT nId TO 0 
	
	(::cAlias)->( DbGoto( nId ) )
	
	if (::cAlias)->( Rlock() )
	
		for n := 1 to len( hRow )
			aPair 	:= HB_HPairAt( hRow, n )
			cField	:= aPair[1]
			uValue	:= aPair[2]			
			nPos 	:= (::cAlias)->( FieldPos( cField ) )
			
			if nPos > 0
			
				if  ::lSaveUtf8ToAnsi .and. valtype( uValue ) == 'C'
					uValue := U8TOUNI( uValue, UTYPE_ANSI )
				endif 
				
				(::cAlias)->( FieldPut( nPos, uValue ) )
			endif						
			
		next 			
	
		(::cAlias)->( dbRUnlock() )
		
		lOk := .t. 
		
	endif 					

retu lOk

//----------------------------------------------------------------------------//

METHOD Delete( nId, hRow ) CLASS TDbf

	local lOk 	:= .f.
	local n, aPair, cField, uValue, nPos 

	DEFAULT nId TO 0 
	
	(::cAlias)->( DbGoto( nId ) )
	
	if (::cAlias)->( Rlock() )
	
		(::cAlias)->( dbDelete() )
		(::cAlias)->( dbRUnlock() )
			
	
		lOk := .t. 
		
	endif 					

retu lOk



//----------------------------------------------------------------------------//

METHOD Add( hRow ) CLASS TDbf

	local lOk 	:= .f.
	local n, aPair, cField, uValue, nPos 
	
	
	if (::cAlias)->( DbAppend() )	

		lOk := .t. 
	
		for n := 1 to len( hRow )
		
			aPair 	:= HB_HPairAt( hRow, n )
			cField	:= aPair[1]
			uValue	:= aPair[2]			
			nPos 	:= (::cAlias)->( FieldPos( cField ) )
			
			if nPos > 0
				(::cAlias)->( FieldPut( nPos, uValue ) )
			endif						
			
		next 			
	
		(::cAlias)->( dbRUnlock() )				
		
	endif 					

retu lOk
