{% LoadFile( "/src/model/tdbf.prg" ) %}

//	El objetivo de crear un modelo es crear una clase que nos encapsule una
//	entidad, tabla, estructura,... para poderla manejar desde qualquier parte
//	de nuestro controlador
//----------------------------------------------------------------------------//
//	The objective of creating a model is to create a class that encapsulates a
//	entity, table, structure, ... to be able to handle it from anywhere
//	of our controller


//	Nosotros creamos un modelo muy basico a modo de concepto.
//	Heredar� de la clase TDbf (una clase senzilla para este test)
//	Tu puedes cambiar esta clase por cualquiera 
//----------------------------------------------------------------------------//
//	We created a very basic model as a concept.
//	It will inherit from the TDbf class (a simple class for this test)
//	You can change this class for anyone

//	Quizas a tener en cuenta, que nosotros cargamos la clase principal TDbf en la 
//	linea superior con la funcion LoadFile(). Recordad que nosotros no enlazamos
//	todas las funciones como hacemos cuando creamos un exe. Por lo tanto deberemos
//	siempre especificar los diferentes modulos que usaremos.
//	Observa tambien que ponemos la funcion entre los tags { %  ...  % }. Estos tags
//	Indican al mod pre-ejecutar el codigo que tiene dentro antes de compilar el m�dulo
//----------------------------------------------------------------------------//
//	Maybe to keep in mind, that we load the main TDbf class in the
//	top line with the LoadFile() function. Remember that we do not link
//	all the functions as we do when we create an exe. Therefore we must
//	always specify the different modules that we will use.
//	Also notice that we put the function between the { % ...  % } tags. These tags
//	They tell the mod to pre-execute the code it has inside before compiling the module



CLASS TestModel FROM TDbf	

	DATA cAlias	

	METHOD New()             		CONSTRUCTOR

	METHOD Get( nId )	
	
ENDCLASS

//----------------------------------------------------------------------------//

METHOD New() CLASS TestModel

	local cPath		:= AppPathData() 
	
	::Open( cPath + 'test', cPath + 'test' ) 
	
RETU SELF


//	-----------------------------------------------

METHOD Get( nId ) CLASS TestModel
	
	DEFAULT nId TO  0

	(::cAlias)->( DbGoTo( nId ) )
	
retu ::Load()		
	
//	-----------------------------------------------