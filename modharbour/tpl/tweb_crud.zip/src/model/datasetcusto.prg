#include {% TWebInclude() %}

function OpenDatasetCusto( cAlias ) 
	
	local cDbf			:=  AppPathData() + 'test.dbf'	
	local o, oDataset
	
	USE (cDbf) SHARED NEW VIA 'DBFCDX'
	
	cAlias := Alias()
	
	SET DATE FORMAT TO 'YYYY-MM-DD'
	SET DELETED ON		
	
	DEFINE BROWSE DATASET o ALIAS cAlias 

		FIELD 'first' 		UPDATE  OF o
		FIELD 'last'  		UPDATE 	VALID {|o, uValue, hRow| NoPPP( o, uValue, hRow ) } OF o
		FIELD 'street'  	UPDATE 	OF o
		FIELD 'city'   				OF o
		FIELD 'state'  				OF o
		FIELD 'zip'  				OF o
		FIELD 'hiredate'  	UPDATE 	OF o
		FIELD 'married'  	UPDATE 	OF o
		FIELD 'age'    		UPDATE 	VALID {|o, uValue, hRow| MaxAge( o, uValue, hRow ) } OF o
		FIELD 'notes'  		UPDATE	NOESCAPE OF o	
		
	//	We can't need fields for security 
	
		//FIELD 'salary'  		OF o		//	we can't use this field. Top secret ! 
	
	//	We can validate before save...
		o:bBeforeSave := {|oDataset, hRow, cAction | CheckDemoRow( oDataset, hRow, cAction  ) }
	
	//	o:Field( 'virtual', nil, {|cAlias, row| Virtual(cAlias, row) } )	//	Not yet
	
retu o

function CheckDemoRow( oDataset, hRow, cAction  ) 

_d( 'Checkdemo')
_d( hRow )

	if hRow[ '_recno' ] <= 3
	_d( 'ERROR')
		oDataset:SetError( 'Rows 1 to 3 only form demo' )
		
		retu .f.	
	endif 


retu .t.

function MaxAge( o, uValue, hRow ) 

	local nAge 		:= if( valtype(uValue) == 'N', uValue, val( uValue )) 	
	local lValid 	:= .t.
	local cMsg 		:= ''
	
	if ! ( nAge > 0 .and. nAge < 100 )
	
		cMsg := '<b>Age</b> Value out of range: ' + valtochar( uValue )				
		
		o:SetError( cMsg )

		lValid := .f.
		
	endif	

retu  lValid

function NoPPP( o, uValue, hRow) 

	local lValid := .t.
	local cMsg 	:= ''
	
	if uValue == 'PPP'
	
		cMsg := '<b>Street</b> PPP no permitido' 
				
		o:SetError( cMsg )
		
		lValid := .f.
	endif	
	
retu  lValid

