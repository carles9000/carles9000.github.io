//	------------------------------------------------------------------------------
//	Project.......: menu_browse
//	Description...: CRUD Example with TWeb
//	Date..........: 31/07/2021  
//	Authors.......: Carles Aubia
//	------------------------------------------------------------------------------

	{% LoadHrb( 'lib/mercury/mercury.hrb' ) %}		//	Loading system MVC Mercury
	{% LoadHrb( 'lib/tweb/tweb.hrb' ) %}			//	Loading TWeb Library
	
//	------------------------------------------------------------------------------

{% MercuryRouter() %}								//	Config system Route
	
function Main()

	InitApp()		
	
retu nil





