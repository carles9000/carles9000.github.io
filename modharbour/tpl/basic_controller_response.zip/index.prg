//	------------------------------------------------------------------------------
//	Project.......: basic_controller_response
//	Description...: Example different output from controller
//	Date..........: 05/06/2021
//	Authors.......: Charly Aubia
//	------------------------------------------------------------------------------

	{% LoadHrb( 'lib/mercury/mercury.hrb' ) %}		//	Loading system MVC Mercury

//	------------------------------------------------------------------------------

{% MercuryRouter() %}
	
	
function main()

	InitApp()
	
return nil 	

