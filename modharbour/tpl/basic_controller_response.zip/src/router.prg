#include {% MercuryInclude() %}

function InitApp()

	local oApp 	
		
	//	Define App

		DEFINE APP oApp 	
		
			//	Cfg. routes Main
				
			DEFINE ROUTE 'root'    		URL '/'      			VIEW 		 'hello.view'  						METHOD 'GET' 	OF oApp		
			
			DEFINE ROUTE 'response.json' 		URL 'response/json' 	CONTROLLER 'json@response.prg'		METHOD 'GET' 	OF oApp	
			DEFINE ROUTE 'response.xml' 		URL 'response/xml' 		CONTROLLER 'xml@response.prg'		METHOD 'GET' 	OF oApp	
			DEFINE ROUTE 'response.html' 		URL 'response/html'		CONTROLLER 'html@response.prg'		METHOD 'GET' 	OF oApp	
			DEFINE ROUTE 'response.401' 		URL 'response/401'		CONTROLLER 'error401@response.prg'	METHOD 'GET' 	OF oApp	
			DEFINE ROUTE 'response.redirect'	URL 'response/redirect'	CONTROLLER 'redirect@response.prg'	METHOD 'GET' 	OF oApp	
			DEFINE ROUTE 'response.view'		URL 'response/view'		CONTROLLER 'view@response.prg'		METHOD 'GET' 	OF oApp	
			
		//	Test sub-folder Controller
		
			DEFINE ROUTE 'my_new'				URL 'new' 				CONTROLLER 'module_a/new.prg'		OF oApp			
			
			
		INIT APP oApp	

return nil

function AppUrlImg(); 				retu App_Url() + '/images/'
function AppUrlLib(); 				retu App_Url() + '/lib/'

