//	Observa que hemos utilizado una funcion en el Router en lugar de una clase.
//	No es aconsejable, porque nos da mas control la clase para posteriormente gestionar 
//	accesos, pero podemos usar esta funcionalidad si asi lo deseamos...
//	-----------------------------------------------------------------------------------
//	Notice that we have used a function on the Router instead of a class. It is not 
//	advisable, because the class gives us more control to later manage accesses, but we
//  can use this functionality if we wish.

FUNCTION Controller( oController )

	oController:View( 'module_a/test.view' )
	
RETU NIL
