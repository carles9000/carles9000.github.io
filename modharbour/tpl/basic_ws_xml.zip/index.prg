//	------------------------------------------------------------------------------
//	Project.......: basic_ws
//	Descripcion...: Esquema básico de un Web Service cons salida xml/json/
//	Description...: Basic scheme of an Web Service with output xml/json
//	Date..........: 22/05/2021
//	Authors.......: Carles Aubia (Charly)
//	------------------------------------------------------------------------------

	{% LoadHrb( 'lib/mercury/mercury.hrb' ) %}		//	Loading system MVC Mercury

//	------------------------------------------------------------------------------

{% MercuryRouter() %}
	
	
function main()

	InitApp()
	
return nil 	

