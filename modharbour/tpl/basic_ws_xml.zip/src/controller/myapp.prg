#include {% MercuryInclude() %}

CLASS MyApp

	METHOD New( oController )			CONSTRUCTOR

	METHOD SearchId()						//	Search Recno
	METHOD SearchState()					//	Search rows with state	
		
ENDCLASS   

//----------------------------------------------------------------------------//

METHOD New( oController ) CLASS MyApp
	
	
RETU Self 


//----------------------------------------------------------------------------//

METHOD SearchId( oController ) CLASS MyApp

	local hParam		:= oController:oRequest:GetAll()
	local hQuery 		:= oController:oRequest:getquery(.t.)	//	Retorna hast de la query --> ?type=xml
	local hData 		:= {=>}
	local oValidator, oTest, cType, cXml
	
	//	Tipo de salida. Default xml
	
		HB_HCaseMatch( hQuery, .F. )
	
		cType 		:= lower( HB_HGetDef( hQuery, 'type', 'xml' ) )

		if !( cType $ 'xml;json'  )
			cType := 'xml'
		endif
	
	//	Validamos parámetros / We validate parameters ------------------------------
	
		DEFINE VALIDATOR oValidator WITH  hParam 

			PARAMETER 'id' 	NAME 'Recno' 	ROLES 'required|numeric|maxlen:8' FORMATTER 'tonumber' OF oValidator				
			
		RUN VALIDATOR oValidator	

		if oValidator:lError								
		
			do case 
				case  cType == 'json'
					oController:oResponse:SendJson( { 'success' => .f., 'error' => oValidator:ErrorString(.f.) } )					
					
				case  cType == 'xml'
			
					cXml := '<xml>'
					cXml += '<success>false</success>'
					cXml += '<error>' + oValidator:ErrorString(.f.) + '</error>'				
					cXml += '</xml>'
				
					oController:oResponse:SendXml( cXml )
			
			endcase 												
			
			retu nil
		endif	
		
	//	Abrimos modelos de datos / Open model data
	
		oTest		:= TestModel():New()

	//	Recuperamos datos del modelo	/ Recover data from model 
		
		hData := oTest:Get( hParam[ 'id' ] )
		
	//	Respuesta / Response 
	
		do case 
			case  cType == 'json'

				oController:oResponse:SendJson( { 'success' => .t. , 'data' => hData })			
			
			case  cType == 'xml'
		
				cXml := '<response>'
				cXml += '<success>true</success>'
				cXml += '<user>'
				
				for n := 1 to len( hData )
				
					aPair := HB_HPairAt( hData, n )
					
					cKey 	:= lower( aPair[1] )
					cValue 	:= valtochar( aPair[2] )			
					
					cXml += '<' + cKey + '>' + valtochar( cValue ) + '</' + cKey + '>'
				
				next 									
				
				cXml += '</user>'
				cXml += '</response>'
				
				oController:oResponse:sendxml( cXml )
				
		endcase 
	
RETU NIL

//----------------------------------------------------------------------------//

METHOD SearchState( oController ) CLASS MyApp

	local hParam		:= oController:oRequest:GetAll()
	local hQuery 		:= oController:oRequest:getquery(.t.)	//	Retorna hast de la query --> ?type=xml
	local aRows 		:= {}
	local nRows 		:= 0
	local nTotal 		:= 0
	local oValidator, oTest, cXml, n, j, cType, hRow, nFields, cKey, aPair, uValue 
	
	
	//	Tipo de salida. Default xml
	
		HB_HCaseMatch( hQuery, .F. )
	
		cType 		:= lower( HB_HGetDef( hQuery, 'type', 'xml' ) )

		if !( cType $ 'xml;json'  )
			cType := 'xml'
		endif	
	
	//	Validamos parámetros / We validate parameters ------------------------------
	
		DEFINE VALIDATOR oValidator WITH  hParam 

			PARAMETER 'state' 	NAME 'State' 	ROLES 'required|maxlen:2' FORMATTER 'upper' OF oValidator				
			
		RUN VALIDATOR oValidator	

		if oValidator:lError					
			
			do case 
				case  cType == 'json'
					oController:oResponse:SendJson( { 'success' => .f., 'error' => oValidator:ErrorString(.f.) } )					
					
				case  cType == 'xml'
			
					cXml := '<xml>'
					cXml += '<success>false</success>'
					cXml += '<error>' + oValidator:ErrorString(.f.) + '</error>'				
					cXml += '</xml>'
				
					oController:oResponse:SendXml( cXml )
			
			endcase 			
			
			retu nil
			
		endif	
		
	//	Abrimos modelos de datos / Open model data
	
		oTest	:= TestModel():New()

	//	Recuperamos datos del modelo	/ Recover data from model 
		
		aRows 	:= oTest:RowsByState( hParam[ 'state' ] )
		nRows 	:= len(aRows) 
		
	//	Calculamos media de edad / We calculate age average
	
		AEval( aRows, {|hRow| nTotal += hRow[ 'AGE'] } )		
		
		nAverage := nTotal / nRows 

		
	//	Respuesta / Response 
		
		do case 
			case  cType == 'json'

				oController:oResponse:SendJson({ 'success' => .t. , 'state' => hParam[ 'state' ], 'len' => nRows, 'average' => nAverage, 'rows' => aRows } )
				
			case  cType == 'xml'
		
				cXml := '<response>'
				cXml += '<success>true</success>'
				cXml += '<state>' + hParam[ 'state' ] + '</state>'
				cXml += '<len>' + ltrim(str(nRows)) + '</len>'
				cXml += '<average>' + ltrim(str(nAverage)) + '</average>'
				cXml += '<rows>'
				
				for n := 1 to len( aRows )				
				
					hRow 		:= aRows[n]
					nFields 	:= len( hRow )
					
					cXml += '<user recno="' + ltrim(str( hRow[ '_recno' ] )) + '">'
					
					for j := 1 to nFields 
				
						aPair 	:= HB_HPairAt( hRow, j )
					
						cKey 	:= lower( aPair[1] )
						cValue 	:= valtochar( aPair[2] )	

						if cKey <> '_recno'
						
							cXml += '<' + cKey + '>' + valtochar( cValue ) + '</' + cKey + '>'
						endif
						
					next
					
					cXml += '</user>'
					
				
				next 									
				
				cXml += '</rows>'
				cXml += '</response>'
				
				oController:oResponse:sendxml( cXml )
				
		endcase 
		
RETU NIL


{% LoadFile( "/src/model/testmodel.prg" ) %}

