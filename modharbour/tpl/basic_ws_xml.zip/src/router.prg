#include {% MercuryInclude() %}

function InitApp()

	local oApp 	
		
	//	Define App

		DEFINE APP oApp ;
			ON INIT MyConfig() 

		//	Initial screen
		
			DEFINE ROUTE 'root'				URL '/' 					VIEW 'default.view'						METHOD 'GET'	OF oApp						
			
		//	Modules...		

			DEFINE ROUTE 'searchrecno'		URL 'searchid/(id)'			CONTROLLER 'searchid@myapp.prg'			METHOD 'GET'	OF oApp
			DEFINE ROUTE 'searchstate'		URL 'searchstate/(state)'	CONTROLLER 'searchstate@myapp.prg'		METHOD 'GET'	OF oApp
				
		INIT APP oApp	

return nil

//	Estas funciones son de soporte para nuestro proyecto
//	These functions are support for our project

//	Path absoluto / absolute path

function AppPathData(); 				retu AP_GetEnv( "DOCUMENT_ROOT" ) + App_Url() + '/data/'


function MyConfig() 

	SET DELETED ON
	SET DATE TO ITALIAN	
	SET CENTURY on	
	
retu nil