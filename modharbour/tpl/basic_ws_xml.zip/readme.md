Hi !

This is a basic example of ws with output xml/json. Default xml 

2 methods are available via GET method. You can put in url browse navigator for test

Information of customer
http://localhost/master/tpl/basic_ws_xml/searchid/1  		where 1 is recno number

Customer list from state
http://localhost/master/tpl/basic_ws_xml/searchstate/ny		where ny is state

You can add query for change output with parameter type. You can use xml or json 

http://localhost/master/tpl/basic_ws_xml/searchid/1?type=json
http://localhost/master/tpl/basic_ws_xml/searchstate/ny?type=json

This example for test purpose don't have autentication. If you want a full example, please 
review basic_ws example. There you can find documentation into doc folder.

Enjoy it ! 