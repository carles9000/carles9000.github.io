CLASS Access

	METHOD New() 	CONSTRUCTOR
	
	METHOD login() 
	METHOD Autentica() 
	METHOD Logout() 	
   
ENDCLASS

METHOD New( oController ) CLASS Access	

	//	En este controlador no autenticamos y permitimos ejecutar cualquier método
	//	In this controller we do not authenticate and allow us to execute any method


RETU SELF

METHOD Login( oController ) CLASS Access

	oController:View( 'sys/login.view' )
	
RETU NIL


METHOD Autentica( oController ) CLASS Access

	LOCAL hData 		:= oController:oRequest:PostAll()
	LOCAL nRecno 		:= 0	
	LOCAL oValidator, oUser 
	LOCAL hUser, hTokenData 
	
	
	//	En este caso nuestro sistema de errores devolverá un hash con la siguiente estructura
	//	success 	= .T./.F.
	//	msg 		= Mensaje de error
	//	-------------------------------------------------------------------------------------------------
	//	Como redirijimos a pantalla de login en caso de error, ya chequearemos si nos llega un parámetro
	//	-------------------------------------------------------------------------------------------------
	//	In this case our error system will return a hash with the following structure
	//	success 	= .T./.F.
	//	msg 		= Error message
	//	-------------------------------------------------------------------------------------------------
	//	As we redirect to the login screen in case of error, we will check if we get a parameter


	//	Validamos parámetros / We validate parameters ------------------------------
		
		DEFINE VALIDATOR oValidator WITH  hData 

			PARAMETER 'user' 	NAME 'User' 	ROLES 'required|string|maxlen:10|minlen:1'  FORMATTER 'lower' OF oValidator
			PARAMETER 'psw'		NAME 'Psw' 		ROLES 'required' OF oValidator					
			
		RUN VALIDATOR oValidator	

		if oValidator:lError					
			oController:View( 'sys/login.view' ,  { 'success' => .F., 'error' => oValidator:ErrorString() } )					
			retu nil
		endif	

	//	Validacion de Usuario / User Validation
	
		oUser := UserModel():New()	
		
		IF oUser:Validate( hData[ 'user' ], hData[ 'psw' ], @nRecno  )			
		
			//	Simulamos que cargamos datos de Usuario del modelo
			//	We simulate that we load User data from the model
			
				hUser 		:= oUser:Get( nRecno )
				
			//	Datos que deseamos incrustar en el token...	( No es obligatorio, pero los podemos usar posteriormente )
			//	Data that we want to embed in the token ... (It is not mandatory, but we can use it later)
			
				hTokenData := { 'entrada' => time(), 'empresa' => 'Intelligence System', 'user' => { 'name' => hUser[ 'NAME' ] }} 			
			
			//	Iniciamos nuestro sistema de validación del sistema basado en JWT
			//	We started our JWT-based system validation system

				DEFINE JWT OF oController WITH hTokenData TIME 10		
			
			//	Mostramos página principal
			//	We show main page

				oController:Redirect( Route( 'app.main' ) )
				
		ELSE
		
			oController:View( 'sys/login.view' , { 'success' => .F., 'error' => 'No se ha podido autenticar correctamente' } )
			
		ENDIF

RETU NIL

METHOD Logout( oController ) CLASS Access

	//	Matamos la cookie que lleva nuestro JSon Web Token (JWT)
	//	We kill the cookie that our JSon Web Token (JWT) carries

	CLOSE JWT OF oController		

	oController:Redirect( Route( 'root' ) )

RETU NIL

//----------------------------------------------------------------------------//
//	Quizas a tener en cuenta, que nosotros cargamos la clase TestModel en la 
//	linea inferior con la funcion LoadFile(). Recordad que nosotros no enlazamos
//	todas las funciones como hacemos cuando creamos un exe. Por lo tanto deberemos
//	siempre especificar los diferentes modulos que usaremos.
//	Observa tambien que ponemos la funcion entre los tags { %  ...  % }. Estos tags
//	Indican al mod pre-ejecutar el codigo que tiene dentro antes de compilar el módulo
//----------------------------------------------------------------------------//
//	Maybe to keep in mind, that we load the TestModel class in the
//	bottom line with the LoadFile() function. Remember that we do not link
//	all the functions as we do when we create an exe. Therefore we must
//	always specify the different modules that we will use.
//	Also notice that we put the function between the { % ...  % } tags. These tags
//	They tell the mod to pre-execute the code it has inside before compiling the module

{% LoadFile( "/src/model/usermodel.prg" ) %}