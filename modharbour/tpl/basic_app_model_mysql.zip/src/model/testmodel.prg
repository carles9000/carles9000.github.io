//	TestModel usará MySql 
//	En este caso usa una pequeña libreria WDO, pro puedes usar mysql nativo.
//	------------------------------------------------------------------------
//	TestModel will use mysql 
//	In this case use a small WDO library, pro you can use native mysql


CLASS TestModel 

	DATA oDb

	METHOD New()             		CONSTRUCTOR

	METHOD Count()	
	METHOD Get( nId )	
	METHOD RowsByState( cState )	
	
ENDCLASS

//----------------------------------------------------------------------------//

METHOD New() CLASS TestModel

	::oDb := WDO():Rdbms( 'MYSQL', "localhost", "harbour", "password", "dbHarbour", 3306 )
	
RETU SELF


//	-----------------------------------------------

METHOD Count() CLASS TestModel

	local nCount := 0
	local hRes 

	if !empty( hRes := ::oDb:Query( "SELECT count(*) as total FROM customer" ) )
	
		oRs := ::oDb:Fetch_Assoc( hRes )
		
		nCount := oRs[ 'total' ]
		
	endif 	
	
retu nCount


//	-----------------------------------------------

METHOD Get( nId ) CLASS TestModel

	local hRow 	:= {=>} 
	local hRes 
	
	DEFAULT nId TO  0

	if !empty( hRes := ::oDb:Query( "select * from customer where id = '" + ltrim(str( nId )) + "' " ) )
	
		hRow := ::oDb:Fetch_Assoc( hRes )
		
	endif 	
	
retu hRow
	
//	-----------------------------------------------


METHOD RowsByState( cState ) CLASS TestModel

	local aRows := {}
	
	DEFAULT cState TO  ''

	if !empty( hRes := ::oDb:Query( "select * from customer where state = '" + cState + "' " ) )
	
		aRows := ::oDb:FetchAll( hRes, .t. )
		
	endif 		

retu aRows