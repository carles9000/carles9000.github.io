//	Esta clase es solo un simple ejemplo, para crear nuestros modelos
//	Tu puedes usar las clases que mas se adapten a tus propositos
//----------------------------------------------------------------------------//
//	This class is just a simple example, to create our models
//	You can use the classes that best suit your purposes

//	Basicamente podrá abrir nuestra tabla, cambiar tag de indice y cargar un registro
//	Basically you can opening our table, changing the index tag and loading a record

CLASS TDbf

	DATA cAlias 				INIT ''

	METHOD New()				CONSTRUCTOR
	
	METHOD Open()		
	METHOD Focus( cFocus )	INLINE (::cAlias)->( OrdSetFocus( cFocus ) )
	METHOD Count()				INLINE (::cAlias)->( RecCount() )

	METHOD Load()
		
ENDCLASS   

//----------------------------------------------------------------------------//

METHOD New() CLASS TDbf

	

RETURN Self 

//----------------------------------------------------------------------------//

METHOD Open( cDbf, cCdx ) CLASS TDbf

	local cAlias := 'A' + ltrim(str( hb_milliseconds() ))

	USE ( cDbf ) SHARED NEW ALIAS &(cAlias) VIA 'DBFCDX'
	SET INDEX TO ( cCdx )
	
	::cAlias := Alias()	

RETU ::cAlias


//----------------------------------------------------------------------------//

METHOD Load( aFields, cAlias ) CLASS TDbf

	local hRow := {=>}
	local nI
	local nFields, uValue, cField, cType
	local lAllFields := .F.

	DEFAULT aFields TO {}
	DEFAULT cAlias TO ::cAlias
	
	
	//	Si no pasamos aFields, cargamos todos los campos...
	
	if empty( aFields ) 	
		nFields 	:= (cAlias)->( FCount() )
		lAllFields := .T.
	else	
		nFields := len( aFields )
	endif			
	
	hRow[ '_recno' ] := (cAlias)->( Recno() )
	
	for nI := 1 to nFields
	
		if lAllFields 
			cField := (cAlias)->( FieldName(nI) )
			uValue := (cAlias)->( FieldGet(nI))
		else
			cField := aFields[nI]
			uValue := (cAlias)->( FieldGet( FieldPos( cField ) ) )
		endif				
		
		cType  := Valtype( uValue )
		
		do case		
			case cType == 'C' ; uValue := UHtmlEncode( alltrim(uValue) )
			case cType == 'D' ; uValue := DToC( uValue )			
		endcase		
	
		hRow[ cField ] := uValue
	
	next

retu hRow 	