Hi !

In /data folder you find customer.sql.zip that shold be install to
mysql server for try this example 

enjoy it ! 