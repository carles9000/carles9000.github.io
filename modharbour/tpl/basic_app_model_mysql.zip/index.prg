//	------------------------------------------------------------------------------
//	Project.......: basic_app with mysql model
//	Descripcion...: Esquema básico de una aplicacion MVC con autenticación and Dbf&Mysql
//	Description...: Basic scheme of an MVC application with authentication and Dbf&Mysql
//	Date..........: 22/05/2021
//	Authors.......: Carles Aubia (Charly)
//	------------------------------------------------------------------------------

	{% LoadHrb( 'lib/mercury/mercury.hrb' ) %}					//	Loading system MVC Mercury
	{% LoadHrb( 'lib/wdo/wdo.hrb' ) %}							//	Loading WDO 
	
//	------------------------------------------------------------------------------

{% MercuryRouter() %}
	
	
function main()

	InitApp()
	
return nil 	

