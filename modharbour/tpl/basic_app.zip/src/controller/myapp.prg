#include {% MercuryInclude() %}

CLASS MyApp

	METHOD New( oController )			CONSTRUCTOR

	METHOD Default( oController )				
	METHOD Main( oController )	

	METHOD test1()				//	Módulos del sistema / System modules
	METHOD test2()				//	Módulos del sistema	/ System modules
	METHOD test3()				//	Módulos del sistema	/ System modules
		
ENDCLASS   

//----------------------------------------------------------------------------//

METHOD New( oController ) CLASS MyApp

	//	Punto importante de la aplicacion. Seguridad del sistema
	//	Podemos de una manera muy sencilla controlar el acceso a este controlador
	//	En este caso le indicamos que en el caso de NO estar autenticado, se dirija 
	//	a la pantalla definida el el router con la clave 'sys.login'
	//	
	//	En un controlador podemos tener varios metodos y es posible que alguna queramos
	//	que sea publico. En este caso podemos crear excepciones con el command 
	//	EXCEPTION <nombre de metodo/s>. Aqui lo hacemos con el método 'test2'
	//	--------------------------------------------------------------------------------
	//	Important point of the application. System security
	//	We can in a very simple way control access to this controller
	//	In this case we indicate that in the case of NOT being authenticated, go
	//	to the screen defined on the router with the key 'sys.login'
	//
	//	In a controller we can have several methods and it is possible that some of us want
	//	make it public. In this case we can create exceptions with the command
	//	EXCEPTION <method name / s>. Here we do it with the 'test2' method

		AUTENTICATE CONTROLLER oController ;
			ERROR ROUTE 'sys.login' ;
			EXCEPTION 'test2'
	
	
	//	Si se llega a este punto es que se ha autenticado correctamente... :-) 
	//	If you get to this point, you have successfully authenticated ... :-)		
	
RETU Self 

//----------------------------------------------------------------------------//

METHOD Default( oController ) CLASS MyApp	

	oController:View( 'default.view' )

RETU nil

//----------------------------------------------------------------------------//

METHOD Main( oController ) CLASS MyApp	

	oController:View( 'main.view' )

RETU nil

//----------------------------------------------------------------------------//

METHOD Test1( o ) CLASS MyApp

	o:View( 'app/test1.view' )
	
RETU NIL

//----------------------------------------------------------------------------//
//	Este método se podra ejecutar sin necesidad de autenticarse. Ver método New()
//	En cualquier momento podremos en la url especificar ../basic_app/app/test2
//----------------------------------------------------------------------------//
//	This method can be executed without the need to authenticate. See New() method
//	At any time we can specify in the url ../basic_app/app/test2
//----------------------------------------------------------------------------//

METHOD Test2( o ) CLASS MyApp

	o:View( 'app/test2.view' )
	
RETU NIL

//----------------------------------------------------------------------------//

METHOD Test3( oController ) CLASS MyApp

	local hData 
	
	GET JWT hData OF oController		//	It's the same -> oController:oMiddleware:hJWTata

	oController:View( 'app/test3.view', hData )
	
RETU NIL

//----------------------------------------------------------------------------//
