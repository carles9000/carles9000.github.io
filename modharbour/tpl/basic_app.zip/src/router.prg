#include {% MercuryInclude() %}

function InitApp()

	local oApp 	
		
	//	Define App

		DEFINE APP oApp ;
			ON INIT MyConfig() ;
			CREDENTIALS 'mERCuRy@2021!' COOKIE 'myapp'	

		//	Initial screen
		
			DEFINE ROUTE 'root'			URL '/' 				VIEW 'default.view'					METHOD 'GET'	OF oApp			
			
		//	Apps screen
		
			DEFINE ROUTE 'app.main'		URL 'app/main'			CONTROLLER 'main@myapp.prg'		METHOD 'GET'	OF oApp
			DEFINE ROUTE 'app.test1'		URL 'app/test1'			CONTROLLER 'test1@myapp.prg'		METHOD 'GET'	OF oApp
			DEFINE ROUTE 'app.test2'		URL 'app/test2'			CONTROLLER 'test2@myapp.prg'		METHOD 'GET'	OF oApp
			DEFINE ROUTE 'app.test3'		URL 'app/test3'			CONTROLLER 'test3@myapp.prg'		METHOD 'GET'	OF oApp

		//	Autentication (Login)
		
			DEFINE ROUTE 'sys.login'		URL 'sys/login'			CONTROLLER 'login@access.prg'		METHOD 'GET'	OF oApp
			DEFINE ROUTE 'sys.autentica'	URL 'sys/autentica'		CONTROLLER 'autentica@access.prg'	METHOD 'POST'	OF oApp
			DEFINE ROUTE 'sys.logout'		URL 'sys/logout'		CONTROLLER 'logout@access.prg'		METHOD 'GET'	OF oApp

				
		INIT APP oApp	

return nil

//	Estas funciones son de soporte para nuestro proyecto
//	These functions are support for our project

//	Path absoluto / absolute path

function AppPathData(); 				retu AP_GetEnv( "DOCUMENT_ROOT" ) + App_Url() + '/data/'


//	Path relativo / relative path

function AppUrlImg(); 				retu App_Url() + '/images/'
function AppUrlLib(); 				retu App_Url() + '/lib/'

function MyConfig() 

	SET DELETED ON
	SET DATE TO ITALIAN	
	SET CENTURY on	
	
retu nil