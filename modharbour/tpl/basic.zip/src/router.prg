#include {% MercuryInclude() %}

function InitApp()

	local oApp 	
		
	//	Define App

		DEFINE APP oApp ;
			ON INIT MyConfig() ;
			CREDENTIALS 'mERCuRy@2021!' COOKIE 'mercury'		
		
			//	Cfg. routes Main
			
			DEFINE ROUTE 'root'    	URL '/'      			VIEW 		'hello.view'  					METHOD 'GET' 	OF oApp		
			DEFINE ROUTE 'main' 		URL 'main'  			CONTROLLER  'main@menu.prg' 				METHOD 'GET' 	OF oApp
			
						
		INIT APP oApp	

return nil

//	Estas funciones son de soporte para nuestro proyecto
//	These functions are support for our project

//	Path relativo / relative path

function AppUrlImg(); 				retu App_Url() + '/images/'
function AppUrlLib(); 				retu App_Url() + '/lib/'


function MyConfig() 

	SET DELETED ON
	SET DATE TO ITALIAN	
	SET CENTURY on	
	
retu nil

