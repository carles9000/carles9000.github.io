#include {% MercuryInclude() %}

function InitApp()

	local oApp 	
		
	//	Define App

		DEFINE APP oApp 
		
			//	Cfg. routes Main
			
			DEFINE ROUTE 'root'    	URL '/'      			VIEW 		'hello.view'  			METHOD 'GET' 	OF oApp								
		
		
		INIT APP oApp	

return nil

//	Estas funciones son de soporte para nuestro proyecto
//	These functions are support for our project

//	Path relativo / relative path

function AppUrlImg(); 				retu App_Url() + '/images/'
function AppUrlLib(); 				retu App_Url() + '/lib/'
