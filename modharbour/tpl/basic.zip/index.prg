//	------------------------------------------------------------------------------
//	Project.......: Basic
//	Description...: Basic structure for MVC 
//	Date..........: 05/06/2021
//	Authors.......: Charly Aubia
//	------------------------------------------------------------------------------

	{% LoadHrb( 'lib/mercury/mercury.hrb' ) %}		//	Loading system MVC Mercury

//	------------------------------------------------------------------------------

{% MercuryRouter() %}
	
	
function main()

	InitApp()
	
return nil 	

