//	------------------------------------------------------------------------------
//	Project.......: Basic_controller_validator
//	Description...: Example how manage validator whne we receive parameters
//	Date..........: 05/06/2021
//	Authors.......: Charly Aubia
//	------------------------------------------------------------------------------

	{% LoadHrb( 'lib/mercury/mercury.hrb' ) %}		//	Loading system MVC Mercury

//	------------------------------------------------------------------------------

{% MercuryRouter() %}
	
	
function main()

	InitApp()
	
return nil 	

