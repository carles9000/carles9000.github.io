#include {% MercuryInclude() %}

function InitApp()

	local oApp 	
		
	//	Define App

		DEFINE APP oApp 
			
		
			//	Cfg. routes Main
				
			DEFINE ROUTE 'root'    		URL '/'      			VIEW 		 'hello.view'  						METHOD 'GET' 	OF oApp		
			
			DEFINE ROUTE 'example1' 		URL 'example1' 			CONTROLLER 'example1@mycontroller.prg'			METHOD 'GET' 	OF oApp			
			DEFINE ROUTE 'validexample1' 	URL 'validexample1' 	CONTROLLER 'validexample1@mycontroller.prg'	METHOD 'POST' 	OF oApp			

			DEFINE ROUTE 'example2' 		URL 'example2' 			CONTROLLER 'example2@mycontroller.prg'			METHOD 'GET' 	OF oApp			
			DEFINE ROUTE 'validexample2' 	URL 'validexample2' 	CONTROLLER 'validexample2@mycontroller.prg'	METHOD 'POST' 	OF oApp			
			
			
		INIT APP oApp	

return nil



function AppUrlImg(); 				retu App_Url() + '/images/'
