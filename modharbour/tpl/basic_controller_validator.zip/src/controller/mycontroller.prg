CLASS MyController

	METHOD New() 	CONSTRUCTOR
	
	METHOD Example1() 				//	Init View Example 1
	METHOD Example2() 				//	Init View Example 2
	
	METHOD ValidExample1() 		//	Validator and view
	METHOD ValidExample2() 		//	Validator and json (ajax)			
   
ENDCLASS

METHOD New( o ) CLASS MyController	

RETU SELF

//	---------------------------------------------------------------

METHOD Example1( o ) CLASS MyController

	local hParam := {=>}
	
	//	Iniciamos parámetros / Init parameters
	
		hParam[ 'name' ] := ''
		hParam[ 'age'  ] := ''
		hParam[ 'city' ] := ''
		hParam[ 'dummy'] := ''
	
	//	Enviamos parámetros a la vista / Send parameters to view

		o:View( 'formvalidator.view', hParam )	
	
RETU NIL

METHOD ValidExample1( oController ) CLASS MyController

	local hParam 		:= oController:PostAll()
	local oValidator 
	
	//	Validamos parámetros / we validate parameters
		
		DEFINE VALIDATOR oValidator WITH  hParam 

			PARAMETER 'name' 		NAME 'Name' 	ROLES 'required'  		 			OF oValidator		
			PARAMETER 'age' 		NAME 'Age' 		ROLES 'required|numeric'  			FORMATTER 'tonumber' OF oValidator		
			PARAMETER 'city' 		NAME 'City' 	ROLES 'string|maxlen:5|minlen:2' 	OF oValidator		
			
		RUN VALIDATOR oValidator	

		if oValidator:lError				
			oController:View( 'formvalidator.view', hParam, oValidator:ErrorString()  )
			retu nil
		endif	

	//	En esta linea todos los parámetros son Ok / In this line, all parameters are Ok
	
	//	...
		
	//	Respuesta / response
	
		oController:View( 'formvalidator.view', hParam, 'PARAMETERS SUCCEFULLY !'  )
	
RETU NIL


//	---------------------------------------------------------------

METHOD Example2( o ) CLASS MyController

	local hParam := {=>}
	
	//	Iniciamos parámetros / Init parameters
	
		hParam[ 'name' ] := ''
		hParam[ 'age'  ] := ''
		hParam[ 'city' ] := ''
		hParam[ 'dummy'] := ''
	
	//	Enviamos parámetros a la vista / Send parameters to view

		o:View( 'formvalidator2.view', hParam )	
	
RETU NIL

METHOD ValidExample2( oController ) CLASS MyController

	local hParam 		:= oController:PostAll()
	local oValidator 
	
	//	Validamos parámetros / we validate parameters
		
		DEFINE VALIDATOR oValidator WITH  hParam 

			PARAMETER 'name' 		NAME 'Name' 	ROLES 'required'  		 			OF oValidator		
			PARAMETER 'age' 		NAME 'Age' 		ROLES 'required|numeric'  			FORMATTER 'tonumber' OF oValidator		
			PARAMETER 'city' 		NAME 'City' 	ROLES 'string|maxlen:5|minlen:2' 	OF oValidator		
			
		RUN VALIDATOR oValidator	

		if oValidator:lError				
			oController:oResponse:SendJson( { 'success' => .f., 'msg' => oValidator:ErrorString(), 'detail' => oValidator:ErrorMessages() } )
			retu nil
		endif	

	//	En esta linea todos los parámetros son Ok / In this line, all parameters are Ok
	
	//	...
		
	//	Respuesta / response
	
		oController:oResponse:SendJson( { 'success' => .t. } )
	
RETU NIL

