#include {% MercuryInclude( 'lib/mercury' ) %}

CLASS MyController

	METHOD New( oController )			CONSTRUCTOR

	METHOD Example1( oController )			
	METHOD Example2( oController )			
		
ENDCLASS   

//----------------------------------------------------------------------------//

METHOD New( oController ) CLASS MyController
	

RETU Self 

//----------------------------------------------------------------------------//

METHOD Example1( oController ) CLASS MyController	

	? time()

RETU nil

//----------------------------------------------------------------------------//

METHOD Example2( oController ) CLASS MyController	

	local hParam := {=>}

	hParam[ 'date' ] := date()
	hParam[ 'time' ] := time()
	hParam[ 'name' ] := 'Paul Britman'
	
	oController:View( 'main.view', hParam )

RETU nil