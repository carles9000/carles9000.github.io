Files installed
---------------
data.rc\wdo.db -> project wdo, but not exist code. All is extern files.
data\wdo -> dbf's & images 
files\wdo -> resources files. Important: config_mysql.txt
html\wdo -> example files with all code

Run example
-----------
You need config server and open path \html . Menu -> Config Server

Restart server and from browse navigator -> localhost:81/html/wdo/index.html
