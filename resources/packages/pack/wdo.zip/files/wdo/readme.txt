Configuraci�n WDO_MYSQL
-----------------------

Necesitas copiar el fichero libmysql64.dll donde tengas htdocs o mysql

En tu programa principal debes indicar donde tienes la dll de esta manera:
	HB_SetEnv( 'WDO_PATH_MYSQL', "c:/xampp/htdocs/" )
	
Para los ejemplo se usa la base de datos dbharbour. Tu tienes el script de 
la base de datos en sql\dbharbour.sql.zip 

Si no tienes en cuenta estos pasos, no te funcionaran los ejemplos.

WDO_MYSQL Configuration
-----------------------

You need to copy the libmysql64.dll file wherever you have htdocs or mysql

In your main program you must indicate where you have the dll like this:
	HB_SetEnv( 'WDO_PATH_MYSQL', "c:/xampp/htdocs/" )
	
For the examples the dbharbour database is used. You have the script database 
in sql\dbharbour.sql.zip 

If you do not take these steps into account, the examples will not work for you.