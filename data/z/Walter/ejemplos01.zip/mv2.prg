Static stack := {}

Function Main()
Local prog := { 12,;
                54,;
                'SUMA',;
                6,;
                3,;
                'DIVISION',;
                'DIVISION',;
                'SHOW' }
ejecutar( prog )
return

Function ejecutar( prog )
Local n

For n:= 1 To Len(prog)
   If Valtype( prog[n] ) == "N"
	Push( prog[n] ) // Los n�meros se ponen en el stack.
   Else
	// Los textos son operaciones o funciones.
     Hb_ExecFromArray( prog[n] )
   Endif
Next

Function Push( x )
Aadd( stack, x )
Return

Function Pop()
Local x := Atail( stack )
Adel( stack, Len( stack ), .t. )
Return x

Function Suma()
Push( pop() + pop() )
Return

Function Division()
Local a := pop()
Push( pop() / a )
Return

Function Show()
? pop()
Return


