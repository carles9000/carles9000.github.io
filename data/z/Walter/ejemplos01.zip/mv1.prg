
Static stack := {}

Function Main()
Local prog := { 12,;
                54,;
                '+',;
                6,;
                3,;
                '/',;
                '/',;
                'S' }
ejecutar( prog )
return

Function ejecutar( prog )
Local n, t

For n:= 1 To Len(prog)
   If Valtype( prog[n] ) == "N"
      Push( prog[n] )
   Else
      Switch prog[n]
      Case '+'
         Push( pop() + pop() )
         Exit
      Case '/'
         t := pop()
         Push( pop() / t )
         Exit
      Case 'S'
         ? pop()
         exit
      End
   Endif
Next
Return

Function Push( x )
Aadd( stack, x )
Return

Function Pop()
Local x := Atail( stack )
Adel( stack, Len( stack ), .t. )
Return x

